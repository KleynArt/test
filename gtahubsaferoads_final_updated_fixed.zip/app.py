"""
Aplicación web desarrollada por KleynArt.  Todos los derechos reservados.
Esta aplicación de reportes policiales fue diseñada y creada por KleynArt para uso en divisiones
de tráfico y patrulla.  No se permite su distribución no autorizada ni su uso comercial
sin el consentimiento expreso de KleynArt.  Cualquier intento de copia o modificación
no autorizada constituirá una violación de derechos de autor.
"""

from flask import Flask, render_template, redirect, url_for, request, flash, session, send_from_directory, make_response
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
from typing import Optional
import os
from functools import wraps
from datetime import datetime, timedelta
# Use Python's calendar module with alias to avoid conflicts
import calendar as pycal
import re

# Versión de la aplicación. Actualice este número cuando realice
# cambios importantes. Formato recomendado: vX.Y.Z FECHA(YYYY-MM-DD)
WEB_VERSION = 'v2.3.0 03-11-2025'

def create_app():
    """
    Aplicación principal de Flask configurada para gestionar los reportes de patrullaje.

    Esta función crea y configura la instancia de Flask, inicializa la base de datos
    y define todas las rutas necesarias para el sistema. Se utiliza un enfoque
    basado en funciones decoradoras para proteger rutas que requieran autenticación
    o permisos de administrador.
    """
    app = Flask(__name__, template_folder='templates', static_folder='static')

    # Clave secreta de sesión (reemplazar en producción)
    app.config['SECRET_KEY'] = 'cambia-esta-clave-secreta'

    # Carpeta donde se almacenan las imágenes subidas de perfiles
    upload_folder = os.path.join(app.static_folder, 'uploads')
    os.makedirs(upload_folder, exist_ok=True)
    app.config['UPLOAD_FOLDER'] = upload_folder

    def get_db_connection():
        """Obtiene una conexión a la base de datos SQLite."""
        db_path = os.path.join(os.path.dirname(__file__), 'database.db')
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def init_db():
        """
        Crea las tablas principales en la base de datos si aún no existen y
        configura una cuenta de administrador por defecto.
        """
        conn = get_db_connection()
        cur = conn.cursor()
        # Tabla de usuarios (incluye referencia a rango)
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                name TEXT NOT NULL,
                email TEXT,
                role TEXT DEFAULT 'user',
                approved INTEGER DEFAULT 0,
                profile_image TEXT,
                rank_id INTEGER,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                hash TEXT,
                discord TEXT,
                plate TEXT,
                FOREIGN KEY(rank_id) REFERENCES ranks(id)
            );
            """
        )
        # Tabla de reportes: almacena patrullajes con duración calculada y participación táctica/mutual.
        # Incluye columnas adicionales para tactico_mutual que reemplaza a las antiguas
        # ubicacion y observaciones que pueden permanecer por compatibilidad.
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS reports (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                unit_number TEXT,
                patrol_date TEXT,
                start_time TEXT,
                end_time TEXT,
                duration_hours REAL,
                companions TEXT,
                tactico_mutual TEXT,
                location TEXT,
                description TEXT,
                observations TEXT,
                department_id INTEGER,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(user_id) REFERENCES users(id)
            );
            """
        )

        # Tabla de unidades (vehículos)
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS units (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                unit_number TEXT UNIQUE NOT NULL,
                image TEXT,
                department_id INTEGER
            );
            """
        )
        # Tabla de departamentos
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS departments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                abbreviation TEXT UNIQUE NOT NULL,
                logo TEXT,
                background TEXT
            );
            """
        )

        # Tabla de relación usuario-departamento con rol específico y privilegios adicionales.
        #  - role: determina si el usuario es miembro normal (member) o administrador de división (cupula).
        #  - fto: banderín que indica si es Field Training Officer (solo aplicable a TSU).
        #  - collaborator: banderín para marcar colaboradores (solo TSU).
        #  - community: banderín que indica si el usuario puede publicar fotos a la galería pública.
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS user_departments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                department_id INTEGER NOT NULL,
                role TEXT DEFAULT 'member',
                fto INTEGER DEFAULT 0,
                collaborator INTEGER DEFAULT 0,
                community INTEGER DEFAULT 0,
                approved INTEGER DEFAULT 0,
                FOREIGN KEY(user_id) REFERENCES users(id),
                FOREIGN KEY(department_id) REFERENCES departments(id)
            );
            """
        )

        # Tabla de miembros/acompañantes (compañeros de patrulla)
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS companions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL
            );
            """
        )

        # Tabla de rangos: almacena nombre del rango, parche e información descriptiva
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS ranks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                patch_image TEXT,
                description TEXT
            );
            """
        )

        # Tabla de certificaciones: permite almacenar nombre e imagen opcional
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS certifications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                image TEXT,
                description TEXT
            );
            """
        )
        # Asegurar columna description existe
        try:
            cur.execute("ALTER TABLE certifications ADD COLUMN description TEXT")
        except sqlite3.OperationalError:
            pass

        # Tabla pivote usuario-certificación
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS user_certifications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                certification_id INTEGER NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id),
                FOREIGN KEY(certification_id) REFERENCES certifications(id)
            );
            """
        )

        # Tabla de estadísticas manuales mensuales para categorías adicionales
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS monthly_manual_stats (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                month TEXT NOT NULL,
                asistencia_operativos INTEGER DEFAULT 0,
                liderados_operativos_gate INTEGER DEFAULT 0,
                asistencia_control_express INTEGER DEFAULT 0,
                liderazgos_express INTEGER DEFAULT 0,
                control_velocidad INTEGER DEFAULT 0,
                FOREIGN KEY(user_id) REFERENCES users(id)
            );
            """
        )

        # Tabla de diplomas académicos
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS diplomas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                title TEXT NOT NULL,
                description TEXT,
                image TEXT,
                department_id INTEGER,
                audience TEXT DEFAULT 'department', -- 'department' o 'all'
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(user_id) REFERENCES users(id)
            );
            """
        )

        # Tabla de menciones honoríficas académicas
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS honors (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                title TEXT NOT NULL,
                description TEXT,
                image TEXT,
                department_id INTEGER,
                audience TEXT DEFAULT 'department',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(user_id) REFERENCES users(id)
            );
            """
        )

        # Tabla de registro de notas académicas (visible solo para cúpula)
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS grades (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                date TEXT NOT NULL,
                subject TEXT NOT NULL,
                grade TEXT NOT NULL,
                notes TEXT,
                department_id INTEGER,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                -- Campos adicionales para registrar desempeño de cadetes
                can_patrol TEXT,
                pit_cert TEXT,
                theoretical_grade TEXT,
                card_status TEXT,
                card_grade1 TEXT,
                card_grade2 TEXT,
                double_promotion TEXT,
                FOREIGN KEY(user_id) REFERENCES users(id)
            );
            """
        )
        # Asegurar que las columnas extra existen si la tabla ya estaba creada
        for col_def in [
            ('can_patrol', 'TEXT'),
            ('pit_cert', 'TEXT'),
            ('theoretical_grade', 'TEXT'),
            ('card_status', 'TEXT'),
            ('card_grade1', 'TEXT'),
            ('card_grade2', 'TEXT'),
            ('double_promotion', 'TEXT'),
        ]:
            col, ctype = col_def
            try:
                cur.execute(f"ALTER TABLE grades ADD COLUMN {col} {ctype}")
            except sqlite3.OperationalError:
                pass

        # Tabla de documentos importantes
        # Almacena enlaces y descripciones de documentos por departamento. Si department_id es NULL
        # se considera global para todas las divisiones. La columna image permite incluir un icono
        # o miniatura opcional. created_by registra el usuario que publicó el documento.
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS documents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                department_id INTEGER,
                title TEXT NOT NULL,
                description TEXT,
                link TEXT NOT NULL,
                image TEXT,
                created_by INTEGER,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(department_id) REFERENCES departments(id),
                FOREIGN KEY(created_by) REFERENCES users(id)
            );
            """
        )

        # -------------------------------------------------------------------
        # Actualizar nombres y orden de rangos para la división State Patrol
        # Muchos nombres originales provenían de la Traffic Safety Unit (TSU). Para
        # alinear con la nueva estructura, renombramos las entradas existentes.
        # Nota: esto se aplica globalmente porque la tabla de rangos no tiene
        # columna de departamento. Solo se actualiza si existen estos nombres.
        rank_renames = [
            ('Shift Traffic Officer', 'Trooper Chief'),
            ('Traffic Officer Supervisor', 'Trooper Supervisor'),
            ('Senior Traffic Officer II', 'Senior State Trooper II'),
            ('Senior Traffic Officer I', 'Senior State Trooper I'),
            ('Traffic Officer II', 'State Trooper II'),
            ('Traffic Officer I', 'State Trooper I'),
            ('Traffic Cadet', 'State Trooper Cadet')
        ]
        for old_name, new_name in rank_renames:
            cur.execute("UPDATE ranks SET name=? WHERE name=?", (new_name, old_name))
        # Insertar nuevos rangos si no existen
        def ensure_rank(name, description, patch):
            cur.execute("SELECT id FROM ranks WHERE name=?", (name,))
            if not cur.fetchone():
                cur.execute(
                    "INSERT INTO ranks (name, description, patch_image) VALUES (?,?,?)",
                    (name, description, patch),
                )
        ensure_rank('Trooper Captain', 'Trooper de alto rango que supervisa la división.', None)
        ensure_rank('Trooper Field Supervisor', 'Supervisor de campo para las patrullas.', None)

        # Configuración de visibilidad de secciones académicas por división
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS department_settings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                department_id INTEGER UNIQUE,
                show_diplomas INTEGER DEFAULT 1,
                show_honors INTEGER DEFAULT 1,
                show_grades INTEGER DEFAULT 1,
                show_hall_of_fame INTEGER DEFAULT 1,
                FOREIGN KEY(department_id) REFERENCES departments(id)
            );
            """
        )

        # Tabla de anuncios: admite título, mensaje e imagen opcional
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS announcements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                message TEXT NOT NULL,
                image TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            """
        )

        # Tabla de condecoraciones (awards) para destacar oficiales
        # Incluye columna department_id (división) y audience para definir visibilidad
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS awards (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                title TEXT,
                description TEXT,
                image TEXT,
                department_id INTEGER,
                audience TEXT DEFAULT 'department',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(user_id) REFERENCES users(id),
                FOREIGN KEY(department_id) REFERENCES departments(id)
            );
            """
        )

        # Tabla de informes de incidencias (anteriormente "SP"). Permite registrar reportes de otras actividades
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS sp_reports (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                department_id INTEGER NOT NULL,
                tripulantes TEXT,
                unit_number TEXT,
                report_date TEXT,
                report_type TEXT,
                location TEXT,
                description TEXT,
                image TEXT,
                links TEXT,
                approved INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(user_id) REFERENCES users(id),
                FOREIGN KEY(department_id) REFERENCES departments(id)
            );
            """
        )
        # Si la tabla ya existía, asegurarse de que la columna links exista
        try:
            cur.execute("ALTER TABLE sp_reports ADD COLUMN links TEXT")
        except sqlite3.OperationalError:
            pass
        # Asegurar columnas para T-STOP (vehículo, persona sancionada y captura MDC)
        for col_def in [
            ('stop_vehicle', 'TEXT'),
            ('stop_person', 'TEXT'),
            ('stop_mdc', 'TEXT')
        ]:
            col, ctype = col_def
            try:
                cur.execute(f"ALTER TABLE sp_reports ADD COLUMN {col} {ctype}")
            except sqlite3.OperationalError:
                pass

        # Tabla de comentarios para informes de incidencias (conversaciones tipo foro)
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS sp_report_comments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                report_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                message TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                read_by_trooper INTEGER DEFAULT 0,
                FOREIGN KEY(report_id) REFERENCES sp_reports(id),
                FOREIGN KEY(user_id) REFERENCES users(id)
            );
            """
        )

        # Tabla de notificaciones para usuarios (avisos de comentarios, aprobación o rechazo, etc.)
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS notifications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                message TEXT NOT NULL,
                link TEXT,
                seen INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(user_id) REFERENCES users(id)
            );
            """
        )

        # Tabla de tokens de recuperación de contraseña
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS password_resets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                token TEXT UNIQUE NOT NULL,
                expires_at TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(user_id) REFERENCES users(id)
            );
            """
        )

        # Asegurar que la tabla users tenga una columna remember_token para inicio automático
        try:
            cur.execute("ALTER TABLE users ADD COLUMN remember_token TEXT")
        except sqlite3.OperationalError:
            pass

        # Añadir columnas para recordar ip y agente de usuario si no existen
        try:
            cur.execute("ALTER TABLE users ADD COLUMN remember_ip TEXT")
        except sqlite3.OperationalError:
            pass
        try:
            cur.execute("ALTER TABLE users ADD COLUMN remember_user_agent TEXT")
        except sqlite3.OperationalError:
            pass

        # Tabla de eventos para controles programados y actividades en calendario
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                department_id INTEGER,
                title TEXT NOT NULL,
                description TEXT,
                start_datetime TEXT NOT NULL,
                end_datetime TEXT,
                control_type TEXT,
                location TEXT,
                units_required TEXT,
                invited_departments TEXT,
                banner TEXT,
                attachments TEXT,
                tags TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(user_id) REFERENCES users(id),
                FOREIGN KEY(department_id) REFERENCES departments(id)
            );
            """
        )

        # Añadir columnas para efectos de temporada a settings, si no existen
        for col_def in [
            ('enable_snow', 'INTEGER DEFAULT 0'),
            ('enable_halloween', 'INTEGER DEFAULT 0'),
            ('enable_thanksgiving', 'INTEGER DEFAULT 0'),
            ('enable_preview', 'INTEGER DEFAULT 0')
        ]:
            col, ctype = col_def
            try:
                cur.execute(f"ALTER TABLE department_settings ADD COLUMN {col} {ctype}")
            except sqlite3.OperationalError:
                pass

        # Añadir columna sort_order a rangos para permitir reordenar
        try:
            cur.execute("ALTER TABLE ranks ADD COLUMN sort_order INTEGER")
        except sqlite3.OperationalError:
            pass
        # Inicializar sort_order en caso de que existan filas sin valor
        cur.execute("UPDATE ranks SET sort_order=id WHERE sort_order IS NULL")

        # Renombrar la división TSU a State Patrol y actualizar abreviatura a SP
        cur.execute("UPDATE departments SET name='State Patrol', abbreviation='SP' WHERE abbreviation='TSU' OR name='Traffic Safety Unit'")
        conn.commit()
        conn.close()

        # Asegurar que exista una fila de ajustes por cada departamento
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("SELECT id FROM departments")
        dept_ids = [row['id'] for row in cur.fetchall()]
        for dept_id in dept_ids:
            cur.execute("SELECT id FROM department_settings WHERE department_id=?", (dept_id,))
            if not cur.fetchone():
                cur.execute(
                    "INSERT INTO department_settings (department_id, show_diplomas, show_honors, show_grades, show_hall_of_fame) VALUES (?,?,?,?,?)",
                    (dept_id, 1, 1, 1, 1),
                )
        conn.commit()
        conn.close()

        # Agregar columnas de personalización si no existen
        # (Usamos un PRAGMA para evitar errores si ya existen)
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("PRAGMA table_info(department_settings)")
        cols = [c['name'] for c in cur.fetchall()]
        if 'custom_logo' not in cols:
            try:
                cur.execute("ALTER TABLE department_settings ADD COLUMN custom_logo TEXT")
            except sqlite3.OperationalError:
                pass
        if 'custom_favicon' not in cols:
            try:
                cur.execute("ALTER TABLE department_settings ADD COLUMN custom_favicon TEXT")
            except sqlite3.OperationalError:
                pass
        if 'primary_color' not in cols:
            try:
                cur.execute("ALTER TABLE department_settings ADD COLUMN primary_color TEXT")
            except sqlite3.OperationalError:
                pass
        if 'bg_start' not in cols:
            try:
                cur.execute("ALTER TABLE department_settings ADD COLUMN bg_start TEXT")
            except sqlite3.OperationalError:
                pass
        if 'bg_end' not in cols:
            try:
                cur.execute("ALTER TABLE department_settings ADD COLUMN bg_end TEXT")
            except sqlite3.OperationalError:
                pass
        conn.commit()
        conn.close()

        # Asegurar que la tabla awards tenga columnas department_id y audience
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("PRAGMA table_info(awards)")
        cols_aw = [c['name'] for c in cur.fetchall()]
        if 'department_id' not in cols_aw:
            try:
                cur.execute("ALTER TABLE awards ADD COLUMN department_id INTEGER")
            except sqlite3.OperationalError:
                pass
        if 'audience' not in cols_aw:
            try:
                cur.execute("ALTER TABLE awards ADD COLUMN audience TEXT DEFAULT 'department'")
            except sqlite3.OperationalError:
                pass
        conn.commit()
        conn.close()

    def get_department_settings(dept_id):
        """Obtiene la configuración de visibilidad de secciones para un departamento dado."""
        if not dept_id:
            return {}
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM department_settings WHERE department_id=?", (dept_id,))
        row = cur.fetchone()
        conn.close()
        return dict(row) if row else {}

    @app.context_processor
    def inject_settings():
        """Inyecta en todas las plantillas las opciones de visibilidad de la división actual."""
        dept_id = session.get('current_department_id')
        settings = get_department_settings(dept_id) if dept_id else {}
        return dict(current_dept_settings=settings)

    @app.context_processor
    def inject_version():
        """Inyecta la versión de la aplicación en todas las plantillas para mostrarla en el perfil."""
        return {'web_version': WEB_VERSION}

    @app.before_request
    def load_user_from_cookie():
        """Auto-autentica al usuario si existe un remember_token válido y no hay sesión activa."""
        # Evitar re-ejecutar si ya hay usuario en sesión
        if session.get('user_id'):
            return
        token = request.cookies.get('remember_token')
        if not token:
            return
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM users WHERE remember_token=? AND approved=1", (token,))
        user = cur.fetchone()
        conn.close()
        if user:
            # Verificar que la IP y el agente de usuario coincidan con los almacenados
            remote_ip = request.remote_addr or ''
            user_agent = request.headers.get('User-Agent', '')
            stored_ip = None
            stored_ua = None
            # Algunos motores de SQLite pueden no retornar columnas inexistentes en Row, así que comprobamos claves
            try:
                stored_ip = user['remember_ip']
                stored_ua = user['remember_user_agent']
            except Exception:
                stored_ip = None
                stored_ua = None
            # Si hay valores almacenados, deben coincidir con los actuales
            if stored_ip and stored_ip != remote_ip:
                return
            if stored_ua and stored_ua != user_agent:
                return
            # Restaurar sesión de usuario
            session['user_id'] = user['id']
            session['user_name'] = user['name']
            session['user_role'] = user['role']
            session['profile_image'] = user['profile_image']
            # Cargar divisiones disponibles y seleccionar la primera si existe más de una
            conn2 = get_db_connection()
            cur2 = conn2.cursor()
            cur2.execute(
                "SELECT ud.department_id, d.name, d.abbreviation, d.logo, ud.role AS dept_role "
                "FROM user_departments ud JOIN departments d ON ud.department_id = d.id "
                "WHERE ud.user_id=? AND ud.approved=1",
                (user['id'],)
            )
            depts = cur2.fetchall()
            conn2.close()
            # Administradores globales pueden acceder a todas las divisiones
            if user['role'] == 'admin':
                conn3 = get_db_connection()
                cur3 = conn3.cursor()
                cur3.execute("SELECT id, name, abbreviation, logo FROM departments")
                all_depts = cur3.fetchall()
                conn3.close()
                depts = []
                for d in all_depts:
                    depts.append({'department_id': d['id'], 'name': d['name'], 'abbreviation': d['abbreviation'], 'logo': d['logo'], 'dept_role': 'admin'})
            # Si solo hay una división, seleccionar automáticamente
            if len(depts) == 1:
                d = depts[0]
                if not isinstance(d, dict):
                    d = {k: d[k] for k in d.keys()}
                dep_id = d.get('department_id', d.get('id'))
                session['current_department_id'] = dep_id
                session['current_department_name'] = d.get('name')
                session['current_department_abbr'] = d.get('abbreviation')
                session['current_department_logo'] = d.get('logo')
                session['current_dept_role'] = d.get('dept_role', 'member')
            else:
                # Guardar lista de divisiones disponibles y permitir al usuario seleccionar
                available = []
                for row in depts:
                    if isinstance(row, dict):
                        dd = row
                    else:
                        dd = {k: row[k] for k in row.keys()}
                    dep_id = dd.get('department_id', dd.get('id'))
                    available.append({'id': dep_id, 'name': dd.get('name'), 'abbreviation': dd.get('abbreviation'), 'logo': dd.get('logo'), 'role': dd.get('dept_role', 'member')})
                session['available_departments'] = available
                # No redirigimos aquí porque before_request se ejecuta antes de rutas
        # Asegurar que las tablas existentes tengan las columnas más recientes. Si no, alteramos.
        def ensure_column(table: str, column: str, definition: str):
            """Agrega una columna a la tabla si no existe."""
            conn2 = get_db_connection()
            cur2 = conn2.cursor()
            cur2.execute(f"PRAGMA table_info({table})")
            cols = [c['name'] for c in cur2.fetchall()]
            if column not in cols:
                try:
                    cur2.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")
                    conn2.commit()
                except sqlite3.OperationalError:
                    pass
            conn2.close()

        # Asegurar columnas nuevas en usuarios
        ensure_column('users', 'rank_id', 'INTEGER')
        ensure_column('users', 'hash', 'TEXT')
        ensure_column('users', 'discord', 'TEXT')
        ensure_column('users', 'plate', 'TEXT')

        # Asegurar columnas nuevas en reports
        ensure_column('reports', 'tactico_mutual', 'TEXT')
        ensure_column('reports', 'duration_hours', 'REAL')
        ensure_column('reports', 'companions', 'TEXT')
        ensure_column('reports', 'department_id', 'INTEGER')
        # announcements: agregar columna de imagen si falta
        ensure_column('announcements', 'image', 'TEXT')
        # announcements: agregar columna de department_id si falta
        ensure_column('announcements', 'department_id', 'INTEGER')
        # ranks: agregar columnas patch_image y description si faltan
        ensure_column('ranks', 'patch_image', 'TEXT')
        ensure_column('ranks', 'description', 'TEXT')
        # awards tabla: si no existe, se crea en el CREATE TABLE, pero en caso de bases antiguas, aseguramos sus columnas
        # Campos básicos de asignación o definición de condecoraciones.
        ensure_column('awards', 'user_id', 'INTEGER')
        ensure_column('awards', 'title', 'TEXT')
        ensure_column('awards', 'description', 'TEXT')
        ensure_column('awards', 'image', 'TEXT')
        # awards: agregar columna de department_id si falta
        ensure_column('awards', 'department_id', 'INTEGER')
        # awards: agregar columna de audiencia para distinguir entre premios internos
        # ("department") o globales ("all").  Este campo permite filtrar los logros
        # que aparecerán en el panel de logros recientes.  Si ya existe, no pasa nada.
        ensure_column('awards', 'audience', 'TEXT')
        # certifications: agregar columna de imagen si falta
        ensure_column('certifications', 'image', 'TEXT')

        # Crear tabla de fotos/galería para almacenar imágenes compartidas por los departamentos
        # Usar una nueva conexión para evitar operar sobre una conexión cerrada
        conn_ph = get_db_connection()
        cur_ph = conn_ph.cursor()
        cur_ph.execute(
            """
            CREATE TABLE IF NOT EXISTS photos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                department_id INTEGER,
                description TEXT,
                image TEXT,
                audience TEXT, -- 'department' (solo su división), 'internal' (todas las divisiones internas), 'public' (visible sin login)
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(user_id) REFERENCES users(id),
                FOREIGN KEY(department_id) REFERENCES departments(id)
            );
            """
        )
        conn_ph.commit()
        conn_ph.close()

        # Población inicial de departamentos si no existen. Cada departamento incluye su nombre,
        # abreviatura, logo (imagen en static/images) y fondo predeterminado.  Esto permite
        # soportar múltiples divisiones (CHP, TSU, CTD, TSD) con configuraciones separadas.
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM departments")
        # Declarar lista de departamentos por defecto fuera de la condición para que esté disponible en ambos casos
        # Lista de departamentos por defecto.  A partir de octubre de 2025 la antigua
        # "Traffic Safety Unit" pasa a denominarse "State Patrol" manteniendo la abreviatura
        # TSU para compatibilidad con la base de datos.  El logotipo de la TSU se sustituye
        # por el nuevo emblema de la State Patrol (state_patrol.png en static/images).
        default_departments = [
            ('Commission on the Highway Patrol', 'CHP', 'chp_logo.png', 'background.png'),
            # La división de tráfico del estado se denomina "State Patrol" con abreviatura SP
            ('State Patrol', 'SP', 'tsu_logo.png', 'background.png'),
            ('Central Traffic Division', 'CTD', 'ctd_logo.png', 'background.png'),
            # Renombrar la TSD a Traffic Services Detail
            ('Traffic Services Detail', 'TSD', 'tsd_logo.png', 'background.png'),
        ]
        if cur.fetchone()[0] == 0:
            # Insertar departamentos por defecto
            for name, abbr, logo, bg in default_departments:
                cur.execute(
                    "INSERT INTO departments (name, abbreviation, logo, background) VALUES (?, ?, ?, ?)",
                    (name, abbr, logo, bg),
                )
            conn.commit()
        else:
            # Si ya existen, actualizar logos a los archivos actuales según abreviatura
            for name, abbr, logo, bg in default_departments:
                # Actualizar tanto el nombre como el logo para mantener consistencia
                cur.execute("UPDATE departments SET name=?, logo=? WHERE abbreviation=?", (name, logo, abbr))
            conn.commit()

            # Actualizar cualquier registro antiguo de la Traffic Safety Unit (TSU) para que pase a ser State Patrol (SP)
            # Esto garantiza que las bases de datos existentes que tenían la TSU utilicen el nuevo nombre y abreviatura.
            cur.execute(
                "UPDATE departments SET name=?, abbreviation='SP', logo=? WHERE abbreviation='TSU' OR name='Traffic Safety Unit'",
                ('State Patrol', 'tsu_logo.png')
            )
            conn.commit()
        conn.close()

        # Asegurar que la tabla units tenga referencia al departamento
        ensure_column('units', 'department_id', 'INTEGER')
        # Asegurar que la tabla user_departments tenga la columna community para roles de Community Manager
        ensure_column('user_departments', 'community', 'INTEGER DEFAULT 0')

        # Población de tablas iniciales para unidades y acompañantes
        conn = get_db_connection()
        cur = conn.cursor()
        # Unidades predeterminadas
        cur.execute("SELECT COUNT(*) FROM units")
        if cur.fetchone()[0] == 0:
            default_units = [
                '22 114', '22 115', '22 116', '11 117', '11 118', '11 119', '11 120',
                '11 121', '11 122', '11 123', '22 95', '11 91', '22 93', 'WOLFF08', 'WOLFF09'
            ]
            for number in default_units:
                cur.execute("INSERT INTO units (unit_number) VALUES (?)", (number,))
            conn.commit()
            # Asociar las unidades predeterminadas al departamento State Patrol por defecto
            # Buscar ID de la abreviatura 'SP'
            cur.execute("SELECT id FROM departments WHERE abbreviation=?", ('SP',))
            sp_row = cur.fetchone()
            if sp_row:
                spid = sp_row['id']
                cur.execute("UPDATE units SET department_id=? WHERE department_id IS NULL", (spid,))
                conn.commit()
        # Acompañantes predeterminados
        cur.execute("SELECT COUNT(*) FROM companions")
        if cur.fetchone()[0] == 0:
            default_companions = [
                'Kleyn Kojima', 'Matthew Specter', 'Fausto Lopes', 'Batiste Suarez', 'Mauricio Savelli',
                'Juan Terroba', 'Emanuel Silva', 'Elon Johnson', 'Natalia Bowlers', 'Santiago Voight',
                'Omar Cortijo', 'David Lopes', 'Lior Sael', 'Alfred García', 'Lionel Martinez',
                'Kooper Reyes', 'David Oliviera', 'Ethan Barnes', 'Ronnie Rossi', 'Louis Alvarado',
                'James Alonso', 'Aiden Torres', 'Jayden Torres', 'Alejandro Ferreira', 'Azul Feller',
                'Brad Sanabria', 'Erik Haakon', 'Frank Mitchell', 'Freddy Montero', 'Jhonhairo Cruz',
                'Jhons Brown', 'John Stuart', 'Lily Loughty', 'Marlon Williams', 'Martin Segovia',
                'Ollie Anderson', 'Owen Rossi', 'Ray Smith', 'Robert Grayson', 'Sergio Morris'
            ]
            for name in default_companions:
                cur.execute("INSERT INTO companions (name) VALUES (?)", (name,))
            conn.commit()
        conn.close()

        # Crear usuario administrador inicial si no existe
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("SELECT id FROM users WHERE role='admin'")
        if not cur.fetchone():
            # Credenciales por defecto: admin / admin123
            password_hash = generate_password_hash('admin123')
            cur.execute(
                "INSERT INTO users (username, password, name, email, role, approved) VALUES (?, ?, ?, ?, ?, ?)",
                ('admin', password_hash, 'Administrador', 'admin@example.com', 'admin', 1),
            )
            conn.commit()
        conn.close()

        # Población de rangos predeterminados y asignación inicial de rangos
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM ranks")
        if cur.fetchone()[0] == 0:
            # Lista de rangos oficiales de la State Patrol con posibles descripciones. La imagen del parche se puede ajustar manualmente.
            default_ranks = [
                ('Traffic Officer Cadet', None, 'Nivel inicial de formación para nuevos oficiales de tráfico.'),
                ('Traffic Officer I', None, 'Oficial de tráfico de nivel I.'),
                ('Traffic Officer II', None, 'Oficial de tráfico de nivel II con experiencia.'),
                ('Senior Traffic Officer I', 'Senior_Traffic_Officer_I.png', 'Oficial de tráfico senior de nivel I.'),
                ('Senior Traffic Officer II', None, 'Oficial de tráfico senior de nivel II.'),
                ('Traffic Officer Supervisor', None, 'Supervisor de oficiales de tráfico.'),
                ('Shift Traffic Officer', None, 'Oficial de tráfico encargado del turno.')
            ]
            for name, img, desc in default_ranks:
                cur.execute("INSERT INTO ranks (name, patch_image, description) VALUES (?, ?, ?)", (name, img, desc))
            conn.commit()
        # Asignar un rango por defecto a Kleyn Kojima si existe como usuario
        # Buscamos el rango 'Senior Traffic Officer I'
        cur.execute("SELECT id FROM ranks WHERE name=?", ('Senior Traffic Officer I',))
        row = cur.fetchone()
        rank_senior_id = row['id'] if row else None
        if rank_senior_id:
            # buscar usuario con nombre exacto y asignar rango si aún no tiene
            cur.execute("SELECT id, rank_id FROM users WHERE name=?", ('Kleyn Kojima',))
            user_row = cur.fetchone()
            if user_row and not user_row['rank_id']:
                cur.execute("UPDATE users SET rank_id=? WHERE id=?", (rank_senior_id, user_row['id']))
                conn.commit()
        conn.close()

    # Inicializar base de datos al iniciar
    init_db()

    def send_notification(user_id: int, title: str, message: str, link: Optional[str] = None):
        """Crea una notificación para un usuario dado."""
        try:
            conn = get_db_connection()
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO notifications (user_id, title, message, link) VALUES (?,?,?,?)",
                (user_id, title, message, link)
            )
            conn.commit()
            conn.close()
        except Exception:
            pass

    @app.before_request
    def load_notifications_count():
        """Carga el número de notificaciones no vistas para el usuario en la sesión."""
        if 'user_id' in session:
            try:
                conn = get_db_connection()
                cur = conn.cursor()
                cur.execute(
                    "SELECT COUNT(*) AS c FROM notifications WHERE user_id=? AND seen=0",
                    (session['user_id'],)
                )
                row = cur.fetchone()
                session['notifications_count'] = row['c'] if row else 0
                conn.close()
            except Exception:
                session['notifications_count'] = 0

    def login_required(f):
        """Decorador que exige inicio de sesión para acceder a una vista."""
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'user_id' not in session:
                return redirect(url_for('login'))
            return f(*args, **kwargs)
        return decorated_function

    def admin_required(f):
        """
        Decorador que restringe el acceso a usuarios con privilegios de administración.
        Se considera administrador global a quienes tienen session['user_role'] == 'admin' (staff) y
        administrador de división (cúpula) a quienes tienen session['current_dept_role'] == 'cupula'.
        Cualquier otra combinación redirige al panel principal con un aviso.
        """
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Verificar inicio de sesión
            if 'user_id' not in session:
                return redirect(url_for('login'))
            is_staff = session.get('user_role') == 'admin'
            is_cupula = session.get('current_dept_role') == 'cupula'
            if not (is_staff or is_cupula):
                flash('Acceso restringido: sólo administradores.', 'warning')
                return redirect(url_for('dashboard'))
            return f(*args, **kwargs)
        return decorated_function

    @app.route('/initdb')
    def initialize_database():
        """Ruta opcional para forzar la inicialización de la base de datos."""
        init_db()
        flash('Base de datos inicializada.', 'info')
        return redirect(url_for('login'))

    @app.route('/')
    def index():
        """Página de inicio: redirecciona según el estado de sesión."""
        if 'user_id' in session:
            return redirect(url_for('dashboard'))
        return redirect(url_for('login'))

    @app.route('/register', methods=['GET', 'POST'])
    def register():
        """
        Permite que los usuarios se registren. Todas las cuentas creadas deben
        ser aprobadas por un administrador antes de iniciar sesión.
        """
        # Obtener departamentos para desplegar en el formulario, incluyendo logo para los chips
        conn_depart = get_db_connection()
        cur_depart = conn_depart.cursor()
        cur_depart.execute("SELECT id, name, abbreviation, logo FROM departments ORDER BY id")
        rows = cur_depart.fetchall()
        # Convertir resultados a lista de diccionarios para un acceso consistente en las plantillas
        departments_list = []
        sp_id = None
        for r in rows:
            d = {k: r[k] for k in r.keys()}
            departments_list.append(d)
            # Identificar ID de State Patrol para mostrar los toggles FTO/Colaborador
            # La abreviatura oficial de State Patrol es 'SP'.
            if d.get('abbreviation') == 'SP':
                sp_id = d['id']
        conn_depart.close()
        if request.method == 'POST':
            username = request.form['username'].strip()
            password = request.form['password']
            name = request.form['name'].strip()
            email = request.form['email'].strip()
            discord = request.form.get('discord', '').strip()
            hash_code = request.form.get('hash', '').strip()
            plate = request.form.get('plate', '').strip()
            # Permitir seleccionar múltiples divisiones. Recogemos la lista de departamentos desde 'departments'.
            # Si el formulario usa solo uno, getlist devuelve un elemento.
            departments_selected = request.form.getlist('departments') or []
            fto = 1 if request.form.get('fto') == 'on' else 0
            collaborator = 1 if request.form.get('collaborator') == 'on' else 0

            # Validación: campos obligatorios y al menos una división seleccionada
            if not username or not password or not name or not departments_selected:
                flash('Por favor complete los campos obligatorios y seleccione al menos una división.', 'warning')
                return render_template('register.html', departments=departments_list, sp_id=sp_id, tagline='Registro')

            conn = get_db_connection()
            cur = conn.cursor()
            # Verificar duplicado de username
            cur.execute("SELECT id FROM users WHERE username=?", (username,))
            if cur.fetchone():
                flash('El nombre de usuario ya existe. Elija otro.', 'danger')
                conn.close()
                return render_template('register.html', departments=departments_list)
            password_hash = generate_password_hash(password)
            # Insertar usuario con campos adicionales y pendiente de aprobación
            cur.execute(
                "INSERT INTO users (username, password, name, email, approved, hash, discord, plate) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (username, password_hash, name, email, 0, hash_code, discord, plate),
            )
            user_id = cur.lastrowid
            # Recuperar abreviaturas de departamentos para aplicar FTO/Colaborador solo a State Patrol
            dept_map = {str(d['id']): d['abbreviation'] for d in departments_list}
            # Insertar asignaciones a departamentos
            for dept_id in departments_selected:
                dept_abbr = dept_map.get(str(dept_id))
                # Solo la State Patrol permite FTO y colaborador
                fto_flag = fto if dept_abbr == 'SP' else 0
                collab_flag = collaborator if dept_abbr == 'SP' else 0
                # Crear asignación con rol por defecto 'member' y comunidad desactivada por defecto
                cur.execute(
                    "INSERT INTO user_departments (user_id, department_id, role, fto, collaborator, community, approved) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (user_id, dept_id, 'member', fto_flag, collab_flag, 0, 0),
                )
            # Actualizar o insertar en companions table
            cur.execute("DELETE FROM companions WHERE name=?", (name,))
            cur.execute("INSERT INTO companions (name) VALUES (?)", (name,))
            conn.commit()
            conn.close()
            flash('Registro exitoso. Espere aprobación.', 'success')
            return redirect(url_for('login'))
        # GET: mostrar formulario de registro con tagline y SP_ID para toggles
        return render_template('register.html', departments=departments_list, sp_id=sp_id, tagline='Registro')

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        """Proceso de inicio de sesión."""
        if request.method == 'POST':
            username = request.form['username']
            password = request.form['password']
            conn = get_db_connection()
            cur = conn.cursor()
            cur.execute("SELECT * FROM users WHERE username=?", (username,))
            user = cur.fetchone()
            conn.close()
            if user and check_password_hash(user['password'], password):
                if user['approved'] == 0:
                    flash('Su cuenta aún no ha sido aprobada por el administrador.', 'warning')
                    return render_template('login.html')
                # Guardar datos generales en la sesión
                session['user_id'] = user['id']
                session['user_name'] = user['name']
                session['user_role'] = user['role']
                session['profile_image'] = user['profile_image']
                # Determinar departamentos asociados aprobados
                conn2 = get_db_connection()
                cur2 = conn2.cursor()
                # Obtener las divisiones a las que pertenece este usuario. Incluimos el rol específico
                # (member o cupula) para cada departamento. Solo se listan aquellas aprobadas.
                cur2.execute(
                    "SELECT ud.department_id, d.name, d.abbreviation, d.logo, ud.role AS dept_role "
                    "FROM user_departments ud JOIN departments d ON ud.department_id = d.id "
                    "WHERE ud.user_id=? AND ud.approved=1",
                    (user['id'],),
                )
                dept_rows = cur2.fetchall()
                conn2.close()
                # Si es administrador global (staff/admin) permitimos ver todos los departamentos
                if user['role'] == 'admin':
                    # Los administradores globales (staff) pueden acceder a todas las divisiones. Para ellos
                    # marcamos el rol como 'admin' en cada departamento.
                    conn3 = get_db_connection()
                    cur3 = conn3.cursor()
                    cur3.execute("SELECT id, name, abbreviation, logo FROM departments")
                    all_depts = cur3.fetchall()
                    conn3.close()
                    dept_rows = []
                    for d in all_depts:
                        # Convertir cada fila a diccionario y asignar rol 'admin' para uso posterior
                        dept_rows.append({
                            'department_id': d['id'],
                            'name': d['name'],
                            'abbreviation': d['abbreviation'],
                            'logo': d['logo'],
                            'dept_role': 'admin'
                        })
                # Preparar respuesta para permitir agregar cookie de recordatorio
                resp = None
                if len(dept_rows) == 1:
                    # Selección única: establecer el departamento actual y su rol
                    d = dept_rows[0]
                    # Convertir a dict si es un sqlite3.Row para usar get() de forma segura
                    if not isinstance(d, dict):
                        d = {k: d[k] for k in d.keys()}
                    dep_id = d.get('department_id', d.get('id'))
                    session['current_department_id'] = dep_id
                    session['current_department_name'] = d.get('name')
                    session['current_department_abbr'] = d.get('abbreviation')
                    session['current_department_logo'] = d.get('logo')
                    # Guardar el rol en la división (admin, cupula o member)
                    session['current_dept_role'] = d.get('dept_role', 'member')
                    resp = make_response(redirect(url_for('dashboard')))
                else:
                    # Guardar lista de departamentos en sesión y redirigir a selección
                    # Convertir a lista de diccionarios sencillos (id, name, abbreviation, logo)
                    available = []
                    for row in dept_rows:
                        # Convertir a diccionario para evitar problemas con sqlite Row
                        if isinstance(row, dict):
                            d = row
                        else:
                            d = {k: row[k] for k in row.keys()}
                        dep_id = d.get('department_id', d.get('id'))
                        available.append({
                            'id': dep_id,
                            'name': d.get('name'),
                            'abbreviation': d.get('abbreviation'),
                            'logo': d.get('logo'),
                            'role': d.get('dept_role', 'member')
                        })
                    session['available_departments'] = available
                    resp = make_response(redirect(url_for('select_department')))
                # Si el usuario marcó "recordarme", generar un token y guardar información de dispositivo
                if request.form.get('remember_me'):
                    # Generar token aleatorio hexadecimal
                    token = os.urandom(32).hex()
                    # Obtener IP remota y agente de usuario para asegurar que el recordatorio sea específico del dispositivo
                    remote_ip = request.remote_addr or ''
                    user_agent = request.headers.get('User-Agent', '')
                    conn4 = get_db_connection()
                    cur4 = conn4.cursor()
                    cur4.execute(
                        "UPDATE users SET remember_token=?, remember_ip=?, remember_user_agent=? WHERE id=?",
                        (token, remote_ip, user_agent, user['id'])
                    )
                    conn4.commit()
                    conn4.close()
                    resp.set_cookie('remember_token', token, max_age=30*24*60*60, httponly=True, samesite='Lax')
                return resp
            flash('Credenciales inválidas.', 'danger')
        # Recuperar lista de departamentos para mostrar logos en la página de inicio de sesión
        conn_d = get_db_connection()
        cur_d = conn_d.cursor()
        cur_d.execute("SELECT id, name, abbreviation, logo FROM departments ORDER BY id")
        depts = cur_d.fetchall()
        conn_d.close()
        return render_template('login.html', departments=depts, tagline='Pantalla de Inicio')

    @app.route('/logout')
    def logout():
        """Cerrar sesión y limpiar variables de sesión."""
        session.clear()
        # Eliminar cookie remember_token
        resp = make_response(redirect(url_for('login')))
        resp.delete_cookie('remember_token')
        flash('Sesión cerrada.', 'info')
        return resp

    @app.route('/select_department', methods=['GET', 'POST'])
    @login_required
    def select_department():
        """
        Permite al usuario seleccionar uno de sus departamentos disponibles. Esta vista se muestra
        después de iniciar sesión cuando el usuario pertenece a más de un departamento. Para
        usuarios con rol de administrador global, se muestran todos los departamentos.
        """
        # Recuperar lista de departamentos desde la sesión
        available = session.get('available_departments') or []
        # Si se envió un departamento por POST, actualizar la sesión y redirigir
        if request.method == 'POST':
            dept_id = request.form.get('department')
            if dept_id:
                # Buscar información del departamento seleccionado
                conn = get_db_connection()
                cur = conn.cursor()
                cur.execute("SELECT id, name, abbreviation, logo FROM departments WHERE id=?", (dept_id,))
                row = cur.fetchone()
                conn.close()
                if row:
                    # Establecer la información del departamento seleccionado
                    session['current_department_id'] = row['id']
                    session['current_department_name'] = row['name']
                    session['current_department_abbr'] = row['abbreviation']
                    session['current_department_logo'] = row['logo']
                    # Determinar el rol dentro de la división seleccionada
                    dept_role = 'member'
                    available = session.get('available_departments', [])
                    for d in available:
                        # Convertir a número para comparación
                        try:
                            aid = int(d.get('id'))
                        except Exception:
                            aid = d.get('id')
                        if aid == int(dept_id):
                            dept_role = d.get('role', 'member')
                            break
                    session['current_dept_role'] = dept_role
                    return redirect(url_for('dashboard'))
        # Indicar al template que se debe mostrar el encabezado de la ciudad en lugar del departamento
        return render_template('select_department.html', departments=available, show_city_header=True, tagline='Seleccione su división')


    @app.route('/department/<int:dept_id>')
    @login_required
    def switch_department(dept_id):
        """Cambia el departamento actual del usuario a otro al que esté asignado."""
        # Verificar que el usuario tenga acceso a este departamento o sea admin
        user_id = session.get('user_id')
        is_admin = session.get('user_role') == 'admin'
        conn = get_db_connection()
        cur = conn.cursor()
        has_access = False
        if is_admin:
            has_access = True
        else:
            cur.execute("SELECT 1 FROM user_departments WHERE user_id=? AND department_id=? AND approved=1", (user_id, dept_id))
            if cur.fetchone():
                has_access = True
        if has_access:
            cur.execute("SELECT id, name, abbreviation, logo FROM departments WHERE id=?", (dept_id,))
            dept = cur.fetchone()
            if dept:
                session['current_department_id'] = dept['id']
                session['current_department_name'] = dept['name']
                session['current_department_abbr'] = dept['abbreviation']
                session['current_department_logo'] = dept['logo']
                # Establecer rol de división
                # Staff mantiene rol admin en todas las divisiones
                if session.get('user_role') == 'admin':
                    session['current_dept_role'] = 'admin'
                else:
                    # Buscar rol específico en user_departments
                    cur.execute(
                        "SELECT role FROM user_departments WHERE user_id=? AND department_id=? AND approved=1",
                        (user_id, dept_id),
                    )
                    row = cur.fetchone()
                    if row:
                        session['current_dept_role'] = row['role']
                    else:
                        session['current_dept_role'] = 'member'
        conn.close()
        return redirect(url_for('dashboard'))

    @app.route('/dashboard')
    @login_required
    def dashboard():
        """Panel principal con resumen de reportes recientes."""
        conn = get_db_connection()
        cur = conn.cursor()
        current_dept = session.get('current_department_id')
        if session.get('user_role') == 'admin':
            # Administrador global: mostrar últimos reportes del departamento seleccionado (o globales) si hay selección
            if current_dept:
                cur.execute(
                    """
                    SELECT reports.*, users.name AS reporter_name
                    FROM reports
                    JOIN users ON reports.user_id = users.id
                    WHERE reports.department_id IS NULL OR reports.department_id=?
                    ORDER BY reports.created_at DESC
                    LIMIT 5
                    """,
                    (current_dept,),
                )
            else:
                cur.execute(
                    """
                    SELECT reports.*, users.name AS reporter_name
                    FROM reports
                    JOIN users ON reports.user_id = users.id
                    ORDER BY reports.created_at DESC
                    LIMIT 5
                    """
                )
        else:
            # Usuario regular: mostrar sus propios reportes en el departamento actual (o globales)
            if current_dept:
                cur.execute(
                    """
                    SELECT * FROM reports
                    WHERE user_id=? AND (department_id IS NULL OR department_id=?)
                    ORDER BY created_at DESC
                    LIMIT 5
                    """,
                    (session['user_id'], current_dept),
                )
            else:
                cur.execute(
                    """
                    SELECT * FROM reports
                    WHERE user_id=?
                    ORDER BY created_at DESC
                    LIMIT 5
                    """,
                    (session['user_id'],),
                )
        reports = cur.fetchall()
        conn.close()
        # Obtener últimos anuncios y condecoraciones filtrados por división
        conn2 = get_db_connection()
        cur2 = conn2.cursor()
        announcements = []
        awards = []
        current_dept = session.get('current_department_id')
        try:
            # Filtrar anuncios: si staff global con selección, filtrar; de lo contrario mostrar los de la división
            if session.get('user_role') == 'admin':
                if current_dept:
                    cur2.execute(
                        "SELECT * FROM announcements WHERE department_id=? ORDER BY created_at DESC LIMIT 3",
                        (current_dept,),
                    )
                else:
                    cur2.execute(
                        "SELECT * FROM announcements ORDER BY created_at DESC LIMIT 3"
                    )
            else:
                cur2.execute(
                    "SELECT * FROM announcements WHERE department_id=? ORDER BY created_at DESC LIMIT 3",
                    (current_dept,),
                )
            announcements = cur2.fetchall()
            # Filtrar condecoraciones y obtener datos de usuario y departamento para mostrar insignias
            # Se muestran premios globales (audience = 'all' o NULL) y aquellos del departamento actual.
            if session.get('user_role') == 'admin':
                if current_dept:
                    cur2.execute(
                        "SELECT awards.*, users.name AS user_name, departments.abbreviation AS department_abbr, departments.logo AS department_logo "
                        "FROM awards "
                        "LEFT JOIN users ON awards.user_id = users.id "
                        "LEFT JOIN departments ON awards.department_id = departments.id "
                        "WHERE (awards.audience IS NULL OR awards.audience='all' OR awards.department_id=?) "
                        "ORDER BY awards.created_at DESC LIMIT 5",
                        (current_dept,),
                    )
                else:
                    # Administrador sin selección de departamento: mostrar todos los premios globales y departamentales
                    cur2.execute(
                        "SELECT awards.*, users.name AS user_name, departments.abbreviation AS department_abbr, departments.logo AS department_logo "
                        "FROM awards "
                        "LEFT JOIN users ON awards.user_id = users.id "
                        "LEFT JOIN departments ON awards.department_id = departments.id "
                        "ORDER BY awards.created_at DESC LIMIT 5"
                    )
            else:
                cur2.execute(
                    "SELECT awards.*, users.name AS user_name, departments.abbreviation AS department_abbr, departments.logo AS department_logo "
                    "FROM awards "
                    "LEFT JOIN users ON awards.user_id = users.id "
                    "LEFT JOIN departments ON awards.department_id = departments.id "
                    "WHERE (awards.audience IS NULL OR awards.audience='all' OR awards.department_id=?) "
                    "ORDER BY awards.created_at DESC LIMIT 5",
                    (current_dept,),
                )
            awards = cur2.fetchall()
            # Convertir timestamps a la zona horaria local (América/Nueva York) para anuncios y premios
            from zoneinfo import ZoneInfo
            def convert_ts(ts):
                try:
                    dt = datetime.strptime(ts, "%Y-%m-%d %H:%M:%S")
                    local_dt = dt.replace(tzinfo=ZoneInfo('UTC')).astimezone(ZoneInfo('America/New_York'))
                    return local_dt.strftime("%Y-%m-%d %H:%M:%S")
                except Exception:
                    return ts
            announcements = [dict(row) for row in announcements]
            for ann in announcements:
                if ann.get('created_at'):
                    ann['created_at'] = convert_ts(ann['created_at'])
            awards = [dict(row) for row in awards]
            for a in awards:
                if a.get('created_at'):
                    a['created_at'] = convert_ts(a['created_at'])
                # Rellenar valores cuando department_id es nulo (global)
                if not a.get('department_abbr'):
                    a['department_abbr'] = 'All'
                    a['department_logo'] = 'lsseal_logo.png'
            # Filtrar premios: mostrar solo aquellos asignados a usuarios y con fecha no superior a 30 días
            try:
                from zoneinfo import ZoneInfo
                now = datetime.now(ZoneInfo('America/New_York'))
            except Exception:
                now = datetime.utcnow()
            filtered_awards = []
            for a in awards:
                # Excluir premios sin usuario asignado (user_id es None o 0)
                if not a.get('user_id'):
                    continue
                created_at_str = a.get('created_at')
                try:
                    # created_at_str ya está en zona local (convert_ts), convertirlo a datetime
                    dt = datetime.strptime(created_at_str, "%Y-%m-%d %H:%M:%S")
                except Exception:
                    # Si el formato es diferente o no se puede parsear, incluirlo sin filtrar
                    filtered_awards.append(a)
                    continue
                # Incluir solo si no supera 30 días de antigüedad
                if (now - dt) <= timedelta(days=30):
                    filtered_awards.append(a)
            awards = filtered_awards
        except Exception:
            announcements = []
            awards = []
        conn2.close()
        return render_template('dashboard.html', reports=reports, announcements=announcements, awards=awards)

    @app.route('/report/new', methods=['GET', 'POST'])
    @login_required
    def create_report():
        """Formulario para crear un nuevo reporte de patrullaje."""
        if request.method == 'POST':
            unit_number = request.form.get('unit_number')
            patrol_date = request.form.get('patrol_date')
            start_time = request.form.get('start_time')
            end_time = request.form.get('end_time')
            # Recuperar datos de acompañantes y participación táctica
            companions_str = request.form.get('companions', '').strip()
            tactico_mutual_list = request.form.getlist('tactico_mutual[]')
            # Convert to string: join with comma, maintain order
            tactico_mutual = ','.join(tactico_mutual_list)
            description = request.form.get('description', '').strip()

            # Calcular duración en horas (puede cruzar medianoche)
            duration_hours = None
            try:
                if patrol_date and start_time and end_time:
                    start_dt = datetime.strptime(f"{patrol_date} {start_time}", "%Y-%m-%d %H:%M")
                    end_dt = datetime.strptime(f"{patrol_date} {end_time}", "%Y-%m-%d %H:%M")
                    # Si la hora final es menor que la inicial asumimos que terminó el día siguiente
                    if end_dt < start_dt:
                        end_dt = end_dt.replace(day=end_dt.day + 1)
                    delta = end_dt - start_dt
                    duration_hours = round(delta.total_seconds() / 3600, 2)
            except Exception:
                duration_hours = None

            conn = get_db_connection()
            cur = conn.cursor()
            # Identificar departamento actual en sesión para asociar el reporte
            department_id = session.get('current_department_id')
            cur.execute(
                """
                INSERT INTO reports (
                    user_id, unit_number, patrol_date, start_time, end_time, duration_hours,
                    companions, tactico_mutual, description, department_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    session['user_id'],
                    unit_number,
                    patrol_date,
                    start_time,
                    end_time,
                    duration_hours,
                    companions_str,
                    tactico_mutual,
                    description,
                    department_id,
                ),
            )
            conn.commit()
            conn.close()
            flash('Reporte de patrullaje registrado correctamente.', 'success')
            return redirect(url_for('dashboard'))

        # Consulta de unidades (incluye imagen)
        conn = get_db_connection()
        cur = conn.cursor()
        current_dept = session.get('current_department_id')
        if current_dept:
            # Mostrar unidades del departamento o sin asignación
            cur.execute("SELECT * FROM units WHERE department_id IS NULL OR department_id=? ORDER BY unit_number", (current_dept,))
        else:
            cur.execute("SELECT * FROM units ORDER BY unit_number")
        units_data = cur.fetchall()
        # Filtrar acompañantes para que solo aparezcan los nombres de miembros de la división actual.
        companions_list = []
        if current_dept:
            # Seleccionar nombres de usuarios que pertenecen a la división actual y han sido aprobados
            cur.execute(
                "SELECT users.name FROM users JOIN user_departments ud ON users.id = ud.user_id "
                "WHERE ud.department_id=? AND ud.approved=1 ORDER BY users.name",
                (current_dept,),
            )
            companions_list = [dict(name=row['name']) for row in cur.fetchall()]
        else:
            # Si no hay división seleccionada (staff), se muestran todos los acompañantes
            cur.execute("SELECT * FROM companions ORDER BY name")
            companions_list = cur.fetchall()
        conn.close()
        # Calcular fecha actual en formato ISO (YYYY-MM-DD) para rellenar por defecto
        current_date = datetime.now().strftime('%Y-%m-%d')
        return render_template('create_report.html', units_list=units_data, companions_list=companions_list, current_date=current_date)

    @app.route('/reports', methods=['GET'])
    @login_required
    def reports():
        """
        Lista de reportes con opciones de filtrado. Los usuarios regulares solo
        verán sus reportes; los administradores pueden ver todos los reportes.
        """
        conn = get_db_connection()
        cur = conn.cursor()

        # Parámetros de filtro
        unit = request.args.get('unit', '').strip()
        user_id = request.args.get('user_id', '').strip()
        start = request.args.get('start', '')
        end = request.args.get('end', '')


        query = """
            SELECT reports.*, users.name AS reporter_name
            FROM reports
            JOIN users ON reports.user_id = users.id
            WHERE 1=1
        """
        params = []

        # Si no es administrador global, restringir a reportes propios y a su departamento (incluso globales)
        current_dept = session.get('current_department_id')
        if session.get('user_role') != 'admin':
            query += " AND reports.user_id=?"
            params.append(session['user_id'])
            if current_dept:
                query += " AND (reports.department_id IS NULL OR reports.department_id=?)"
                params.append(current_dept)
        else:
            # Administrador global: si hay departamento seleccionado, filtra por él pero incluye globales
            if current_dept:
                query += " AND (reports.department_id IS NULL OR reports.department_id=?)"
                params.append(current_dept)
            # Filtrar por usuario específico si se selecciona
            if user_id:
                query += " AND reports.user_id=?"
                params.append(user_id)

        if unit:
            query += " AND unit_number LIKE ?"
            params.append(f"%{unit}%")
        if start:
            query += " AND date(patrol_date) >= date(?)"
            params.append(start)
        if end:
            query += " AND date(patrol_date) <= date(?)"
            params.append(end)

        query += " ORDER BY reports.created_at DESC"

        cur.execute(query, params)
        reports_data = cur.fetchall()

        # Para el filtro de usuario en el panel de administrador
        users_list = []
        if session.get('user_role') == 'admin':
            cur.execute("SELECT id, name FROM users ORDER BY name")
            users_list = cur.fetchall()
        conn.close()
        return render_template(
            'reports.html',
            reports=reports_data,
            users_list=users_list,
            selected_unit=unit,
            selected_user=user_id,
            selected_start=start,
            selected_end=end,
        )

    @app.route('/admin/units', methods=['GET', 'POST'])
    @login_required
    @admin_required
    def manage_units():
        """Panel de administración para las unidades de patrulla."""
        conn = get_db_connection()
        cur = conn.cursor()
        if request.method == 'POST':
            action = request.form.get('action')
            if action == 'add':
                unit_number = request.form.get('unit_number', '').strip()
                file = request.files.get('image')
                image_filename = None
                if file and file.filename:
                    # Guardar imagen en carpeta de uploads general con nombre único
                    image_filename = f"unit_{unit_number}_{int(datetime.utcnow().timestamp())}_{file.filename}"
                    file.save(os.path.join(app.config['UPLOAD_FOLDER'], image_filename))
                if unit_number:
                    # Asociar la nueva unidad al departamento actual si existe
                    department_id = session.get('current_department_id')
                    try:
                        cur.execute(
                            "INSERT INTO units (unit_number, image, department_id) VALUES (?, ?, ?)",
                            (unit_number, image_filename, department_id),
                        )
                        conn.commit()
                        flash('Unidad agregada.', 'success')
                    except sqlite3.IntegrityError:
                        flash('La unidad ya existe.', 'danger')
            elif action == 'edit':
                # Editar unidad existente
                unit_id = request.form.get('unit_id')
                new_number = request.form.get('unit_number_edit', '').strip()
                file = request.files.get('image_edit')
                image_filename = None
                if file and file.filename:
                    image_filename = f"unit_{new_number}_{int(datetime.utcnow().timestamp())}_{file.filename}"
                    file.save(os.path.join(app.config['UPLOAD_FOLDER'], image_filename))
                if unit_id and new_number:
                    if image_filename:
                        cur.execute("UPDATE units SET unit_number=?, image=? WHERE id=?", (new_number, image_filename, unit_id))
                    else:
                        cur.execute("UPDATE units SET unit_number=? WHERE id=?", (new_number, unit_id))
                    conn.commit()
                    flash('Unidad actualizada.', 'success')
            elif action == 'delete':
                unit_id = request.form.get('unit_id')
                if unit_id:
                    cur.execute("DELETE FROM units WHERE id=?", (unit_id,))
                    conn.commit()
                    flash('Unidad eliminada.', 'info')
        # Filtrar unidades mostradas por departamento actual (si existe), incluyendo las globales (department_id IS NULL)
        current_dept = session.get('current_department_id')
        if current_dept:
            cur.execute("SELECT * FROM units WHERE department_id IS NULL OR department_id=? ORDER BY unit_number", (current_dept,))
        else:
            cur.execute("SELECT * FROM units ORDER BY unit_number")
        units = cur.fetchall()
        conn.close()
        return render_template('admin_units.html', units=units)

    @app.route('/admin/ranks', methods=['GET', 'POST'])
    @login_required
    @admin_required
    def manage_ranks():
        """Panel de administración para rangos."""
        conn = get_db_connection()
        cur = conn.cursor()
        if request.method == 'POST':
            action = request.form.get('action')
            if action == 'add':
                name = request.form.get('name', '').strip()
                description = request.form.get('description', '').strip()
                file = request.files.get('image')
                image_filename = None
                if file and file.filename:
                    image_filename = f"rank_{name.replace(' ', '_')}_{int(datetime.utcnow().timestamp())}_{file.filename}"
                    file.save(os.path.join(app.config['UPLOAD_FOLDER'], image_filename))
                if name:
                    try:
                        cur.execute(
                            "INSERT INTO ranks (name, patch_image, description) VALUES (?, ?, ?)",
                            (name, image_filename, description),
                        )
                        conn.commit()
                        flash('Rango agregado.', 'success')
                    except sqlite3.IntegrityError:
                        flash('El rango ya existe.', 'danger')
            elif action == 'delete':
                rank_id = request.form.get('rank_id')
                if rank_id:
                    # Evitar eliminar rangos que estén asignados
                    cur.execute("SELECT COUNT(*) AS c FROM users WHERE rank_id=?", (rank_id,))
                    count = cur.fetchone()['c']
                    if count == 0:
                        cur.execute("DELETE FROM ranks WHERE id=?", (rank_id,))
                        conn.commit()
                        flash('Rango eliminado.', 'info')
                    else:
                        flash('No se puede eliminar un rango asignado a usuarios.', 'warning')
            elif action in ('move_up', 'move_down'):
                rank_id = request.form.get('rank_id')
                if rank_id:
                    rank_id = int(rank_id)
                    # Obtener orden actual
                    cur.execute("SELECT sort_order FROM ranks WHERE id=?", (rank_id,))
                    row = cur.fetchone()
                    if row:
                        current_order = row['sort_order']
                        if action == 'move_up':
                            # Buscar rango inmediatamente anterior
                            cur.execute(
                                "SELECT id, sort_order FROM ranks WHERE sort_order < ? ORDER BY sort_order DESC LIMIT 1",
                                (current_order,)
                            )
                            swap = cur.fetchone()
                        else:
                            # move_down
                            cur.execute(
                                "SELECT id, sort_order FROM ranks WHERE sort_order > ? ORDER BY sort_order ASC LIMIT 1",
                                (current_order,)
                            )
                            swap = cur.fetchone()
                        if swap:
                            swap_id = swap['id']
                            swap_order = swap['sort_order']
                            # Intercambiar sort_order
                            cur.execute("UPDATE ranks SET sort_order=? WHERE id=?", (swap_order, rank_id))
                            cur.execute("UPDATE ranks SET sort_order=? WHERE id=?", (current_order, swap_id))
                            conn.commit()
        # Recuperar rangos ordenados por sort_order
        cur.execute("SELECT * FROM ranks ORDER BY sort_order, id")
        ranks = cur.fetchall()
        conn.close()
        return render_template('admin_ranks.html', ranks=ranks)

    @app.route('/admin/ranks/<int:rank_id>/edit', methods=['GET', 'POST'])
    @login_required
    @admin_required
    def edit_rank(rank_id):
        """
        Permite editar un rango existente. Se puede cambiar el nombre, descripción y parche.
        """
        conn = get_db_connection()
        cur = conn.cursor()
        # Obtener datos del rango
        cur.execute("SELECT * FROM ranks WHERE id=?", (rank_id,))
        rank = cur.fetchone()
        if not rank:
            conn.close()
            flash('Rango no encontrado.', 'danger')
            return redirect(url_for('manage_ranks'))
        if request.method == 'POST':
            name = request.form.get('name', '').strip()
            description = request.form.get('description', '').strip()
            file = request.files.get('image')
            patch_filename = rank['patch_image']
            if file and file.filename:
                # Guardar nuevo parche en uploads
                filename = f"rank_{rank_id}_{file.filename}"
                save_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(save_path)
                patch_filename = filename
            if name:
                cur.execute(
                    "UPDATE ranks SET name=?, description=?, patch_image=? WHERE id=?",
                    (name, description, patch_filename, rank_id),
                )
                conn.commit()
                conn.close()
                flash('Rango actualizado correctamente.', 'success')
                return redirect(url_for('manage_ranks'))
            flash('El nombre del rango es obligatorio.', 'warning')
        conn.close()
        return render_template('admin_rank_edit.html', rank=rank)

    @app.route('/admin/awards', methods=['GET', 'POST'])
    @login_required
    @admin_required
    def manage_awards():
        """Panel de administración para condecoraciones o reconocimientos."""
        conn = get_db_connection()
        cur = conn.cursor()
        # Asegurar que la columna audience exista para evitar errores en bases antiguas
        cur.execute("PRAGMA table_info(awards)")
        cols_aw = [c['name'] for c in cur.fetchall()]
        if 'audience' not in cols_aw:
            try:
                cur.execute("ALTER TABLE awards ADD COLUMN audience TEXT")
                conn.commit()
            except sqlite3.OperationalError:
                pass
        if request.method == 'POST':
            action = request.form.get('action')
            if action == 'delete':
                award_id = request.form.get('award_id')
                if award_id:
                    cur.execute("DELETE FROM awards WHERE id=?", (award_id,))
                    conn.commit()
                    flash('Condecoración eliminada.', 'info')
            else:
                # Determinar tipo de acción para premios: crear, asignar o actualizar definición
                action_form = request.form.get('action')
                if action_form == 'create_definition':
                    # Crear una nueva definición (sin asignar a ningún usuario)
                    title = request.form.get('title', '').strip()
                    description = request.form.get('description', '').strip()
                    file = request.files.get('image')
                    image_filename = None
                    if file and file.filename:
                        safe_title = re.sub(r'[^A-Za-z0-9_\-]', '', title.replace(' ', '_')) or 'award'
                        image_filename = f"award_{safe_title}_{int(datetime.utcnow().timestamp())}_{file.filename}"
                        file.save(os.path.join(app.config['UPLOAD_FOLDER'], image_filename))
                    if title and description:
                        audience = request.form.get('audience', 'department')
                        dept_id_aw = session.get('current_department_id')
                        allow_global = session.get('user_role') == 'admin' or session.get('current_dept_role') == 'cupula'
                        if audience == 'all' and allow_global:
                            dept_id_aw = None
                        cur.execute(
                            "INSERT INTO awards (user_id, title, description, image, department_id, audience) VALUES (?, ?, ?, ?, ?, ?)",
                            (None, title, description, image_filename, dept_id_aw, audience),
                        )
                        conn.commit()
                        flash('Condecoración creada.', 'success')
                elif action_form == 'assign_award':
                    # Asignar una definición existente a un usuario
                    user_id = request.form.get('user_id')
                    def_id = request.form.get('def_id')
                    if user_id and def_id:
                        # Obtener la definición
                        cur.execute("SELECT * FROM awards WHERE id=?", (def_id,))
                        award_def = cur.fetchone()
                        if award_def:
                            # Copiar sus campos para el nuevo registro asignado
                            title = award_def['title']
                            description = award_def['description']
                            image_filename = award_def['image']
                            dept_id_aw = award_def['department_id']
                            audience = award_def['audience']
                            cur.execute(
                                "INSERT INTO awards (user_id, title, description, image, department_id, audience) VALUES (?, ?, ?, ?, ?, ?)",
                                (user_id, title, description, image_filename, dept_id_aw, audience),
                            )
                            conn.commit()
                            flash('Condecoración asignada al usuario.', 'success')
                elif action_form == 'update_definition':
                    # Actualizar una definición existente (sin usuario asignado)
                    def_id = request.form.get('award_id')
                    title = request.form.get('title', '').strip()
                    description = request.form.get('description', '').strip()
                    file = request.files.get('image')
                    image_filename = None
                    if file and file.filename:
                        safe_title = re.sub(r'[^A-Za-z0-9_\-]', '', title.replace(' ', '_')) or 'award'
                        image_filename = f"award_{safe_title}_{int(datetime.utcnow().timestamp())}_{file.filename}"
                        file.save(os.path.join(app.config['UPLOAD_FOLDER'], image_filename))
                    if def_id and title and description:
                        if image_filename:
                            cur.execute(
                                "UPDATE awards SET title=?, description=?, image=? WHERE id=? AND user_id IS NULL",
                                (title, description, image_filename, def_id)
                            )
                        else:
                            cur.execute(
                                "UPDATE awards SET title=?, description=? WHERE id=? AND user_id IS NULL",
                                (title, description, def_id)
                            )
                        conn.commit()
                        flash('Condecoración actualizada.', 'success')
        # Obtener lista de usuarios para selección
        cur.execute("SELECT id, name FROM users ORDER BY name")
        users_list = cur.fetchall()
        # Filtrar condecoraciones por departamento salvo que sea staff global
        current_dept = session.get('current_department_id')
        if session.get('user_role') == 'admin':
            if current_dept:
                cur.execute(
                    "SELECT awards.*, users.name AS user_name FROM awards LEFT JOIN users ON awards.user_id = users.id WHERE awards.department_id=? ORDER BY awards.created_at DESC",
                    (current_dept,),
                )
            else:
                cur.execute(
                    "SELECT awards.*, users.name AS user_name FROM awards LEFT JOIN users ON awards.user_id = users.id ORDER BY awards.created_at DESC"
                )
        else:
            cur.execute(
                "SELECT awards.*, users.name AS user_name FROM awards LEFT JOIN users ON awards.user_id = users.id WHERE awards.department_id=? ORDER BY awards.created_at DESC",
                (current_dept,),
            )
        awards_list = cur.fetchall()
        # Separar en asignaciones (tienen user_id) y definiciones (no tienen user_id)
        assignments = []
        definitions = []
        for row in awards_list:
            rd = dict(row)
            if rd['user_id']:
                assignments.append(rd)
            else:
                definitions.append(rd)
        conn.close()
        # Determinar si el usuario puede crear condecoraciones globales
        allow_global_award = session.get('user_role') == 'admin' or session.get('current_dept_role') == 'cupula'
        return render_template('admin_awards.html', users_list=users_list, awards=assignments, definitions=definitions, allow_global_award=allow_global_award)

    @app.route('/admin/certifications', methods=['GET', 'POST'])
    @login_required
    @admin_required
    def manage_certifications():
        """Panel de administración para certificaciones."""
        conn = get_db_connection()
        cur = conn.cursor()
        if request.method == 'POST':
            action = request.form.get('action')
            if action == 'add':
                name = request.form.get('name', '').strip()
                description = request.form.get('description', '').strip()
                file = request.files.get('image')
                image_filename = None
                if file and file.filename:
                    filename_safe = secure_filename(file.filename)
                    image_filename = f"cert_{name.replace(' ', '_')}_{int(datetime.utcnow().timestamp())}_{filename_safe}"
                    file.save(os.path.join(app.config['UPLOAD_FOLDER'], image_filename))
                if name:
                    try:
                        cur.execute("INSERT INTO certifications (name, image, description) VALUES (?, ?, ?)", (name, image_filename, description))
                        conn.commit()
                        flash('Certificación agregada.', 'success')
                    except sqlite3.IntegrityError:
                        flash('Ya existe una certificación con ese nombre.', 'danger')
            elif action == 'update':
                # Actualizar certificación existente
                cert_id = request.form.get('cert_id')
                name = request.form.get('name', '').strip()
                description = request.form.get('description', '').strip()
                file = request.files.get('image')
                image_filename = None
                if file and file.filename:
                    filename_safe = secure_filename(file.filename)
                    image_filename = f"cert_{name.replace(' ', '_')}_{int(datetime.utcnow().timestamp())}_{filename_safe}"
                    file.save(os.path.join(app.config['UPLOAD_FOLDER'], image_filename))
                if cert_id and name:
                    if image_filename:
                        cur.execute("UPDATE certifications SET name=?, image=?, description=? WHERE id=?", (name, image_filename, description, cert_id))
                    else:
                        cur.execute("UPDATE certifications SET name=?, description=? WHERE id=?", (name, description, cert_id))
                    conn.commit()
                    flash('Certificación actualizada.', 'success')
            elif action == 'delete':
                cert_id = request.form.get('cert_id')
                if cert_id:
                    cur.execute("DELETE FROM user_certifications WHERE certification_id=?", (cert_id,))
                    cur.execute("DELETE FROM certifications WHERE id=?", (cert_id,))
                    conn.commit()
                    flash('Certificación eliminada.', 'info')
        cur.execute("SELECT * FROM certifications ORDER BY name")
        certs = cur.fetchall()
        conn.close()
        return render_template('admin_certifications.html', certifications=certs)

    @app.route('/stats')
    @login_required
    def stats():
        """Muestra estadísticas de patrullajes y horas por miembro para el mes seleccionado.
        Incluye al usuario titular y a sus acompañantes (cada acompañante recibe el mismo cómputo de horas y reporte)."""
        # Determinar mes actual o parámetro
        month_param = request.args.get('month')
        # Calcular el mes en formato UTC para garantizar que la rotación ocurra a medianoche UTC
        month = month_param if month_param else datetime.utcnow().strftime('%Y-%m')
        conn = get_db_connection()
        cur = conn.cursor()
        # Determinar departamento actual
        current_dept = session.get('current_department_id')
        # Obtener usuarios y rangos asociados al departamento (o todos si admin y sin selección)
        if current_dept:
            cur.execute(
                """
                SELECT users.id, users.name, ranks.patch_image
                FROM users
                JOIN user_departments ud ON users.id = ud.user_id
                LEFT JOIN ranks ON users.rank_id = ranks.id
                WHERE ud.department_id=?
                """,
                (current_dept,),
            )
        else:
            cur.execute(
                "SELECT users.id, users.name, ranks.patch_image FROM users LEFT JOIN ranks ON users.rank_id = ranks.id"
            )
        user_rows = cur.fetchall()
        users_info = {row['id']: {'name': row['name'], 'patch_image': row['patch_image']} for row in user_rows}
        # Mapa para lookup por nombre (puede haber nombres duplicados, tomamos el primero)
        name_to_user_id = {}
        for row in user_rows:
            if row['name'] not in name_to_user_id:
                name_to_user_id[row['name']] = row['id']
        # Inicializar acumuladores
        # Inicializar acumuladores incluyendo conteo de informes SP
        agg = {uid: {
            'user_id': uid,
            'name': info['name'],
            'patch_image': info['patch_image'],
            'num_reports': 0,
            'num_sp_reports': 0,
            'total_hours': 0.0
        } for uid, info in users_info.items()}
        # Seleccionar reportes del mes filtrados por división. Para divisiones específicas, solo
        # consideramos reportes asociados a ese department_id, excluyendo registros globales. Para
        # administradores sin división, se muestran todos los reportes.
        if current_dept:
            cur.execute(
                "SELECT user_id, companions, duration_hours FROM reports WHERE strftime('%Y-%m', patrol_date)=? AND department_id=?",
                (month, current_dept),
            )
        else:
            cur.execute(
                "SELECT user_id, companions, duration_hours FROM reports WHERE strftime('%Y-%m', patrol_date)=?",
                (month,),
            )
        reports_rows = cur.fetchall()
        for r in reports_rows:
            # Agregar para reportero
            if r['user_id'] in agg:
                agg[r['user_id']]['num_reports'] += 1
                agg[r['user_id']]['total_hours'] += (r['duration_hours'] or 0)
            # Agregar para acompañantes
            comps = (r['companions'] or '').split(',') if r['companions'] else []
            for comp_name in comps:
                comp_name = comp_name.strip()
                uid = name_to_user_id.get(comp_name)
                if uid and uid in agg:
                    agg[uid]['num_reports'] += 1
                    agg[uid]['total_hours'] += (r['duration_hours'] or 0)
        # Convertir a lista y filtrar sin actividad
        stats_list = [v for v in agg.values() if v['num_reports'] > 0 or v['total_hours'] > 0]
        # Ordenar por horas descendente
        stats_list.sort(key=lambda x: x['total_hours'], reverse=True)
        # Obtener estadísticas manuales para el mismo mes
        if current_dept:
            # Sólo manual stats de usuarios de este departamento
            user_ids = [u['user_id'] for u in stats_list]
            if user_ids:
                placeholders = ','.join('?' * len(user_ids))
                cur.execute(f"SELECT * FROM monthly_manual_stats WHERE month=? AND user_id IN ({placeholders})", [month] + user_ids)
                manual_rows = cur.fetchall()
            else:
                manual_rows = []
        else:
            cur.execute("SELECT * FROM monthly_manual_stats WHERE month=?", (month,))
            manual_rows = cur.fetchall()
        manual_by_user = {row['user_id']: row for row in manual_rows}
        # Calcular número de informes SP aprobados por usuario para el mes y departamento actual
        try:
            # Calcular sólo informes de incidencias aprobados para el mes y departamento actual
            if current_dept:
                cur.execute(
                    "SELECT user_id, COUNT(*) AS c FROM sp_reports WHERE approved=1 AND department_id=? AND strftime('%Y-%m', report_date)=? GROUP BY user_id",
                    (current_dept, month),
                )
            else:
                cur.execute(
                    "SELECT user_id, COUNT(*) AS c FROM sp_reports WHERE approved=1 AND strftime('%Y-%m', report_date)=? GROUP BY user_id",
                    (month,),
                )
            sp_counts = cur.fetchall()
            for row in sp_counts:
                uid = row['user_id']
                if uid in agg:
                    agg[uid]['num_sp_reports'] = row['c']
        except Exception:
            pass
        # Calcular los mejores jugadores en cada categoría para mostrar un resumen (top performers)
        top_patrol = None
        top_incidents = None
        top_hours = None
        top_operativos = None
        top_liderados_oper = None
        top_asist_expres = None
        top_liderazgos_expres = None
        top_control_vel = None
        def get_manual(uid, key):
            row = manual_by_user.get(uid)
            return row[key] if row else 0
        if stats_list:
            top_patrol = max(stats_list, key=lambda x: x['num_reports'])
            top_incidents = max(stats_list, key=lambda x: x['num_sp_reports'])
            top_hours = max(stats_list, key=lambda x: x['total_hours'])
            top_operativos = max(stats_list, key=lambda x: get_manual(x['user_id'], 'asistencia_operativos'))
            top_liderados_oper = max(stats_list, key=lambda x: get_manual(x['user_id'], 'liderados_operativos_gate'))
            top_asist_expres = max(stats_list, key=lambda x: get_manual(x['user_id'], 'asistencia_control_express'))
            top_liderazgos_expres = max(stats_list, key=lambda x: get_manual(x['user_id'], 'liderazgos_express'))
            top_control_vel = max(stats_list, key=lambda x: get_manual(x['user_id'], 'control_velocidad'))
        conn.close()
        return render_template(
            'stats.html',
            stats=stats_list,
            manual_by_user=manual_by_user,
            month=month,
            top_patrol=top_patrol,
            top_incidents=top_incidents,
            top_hours=top_hours,
            top_operativos=top_operativos,
            top_liderados_oper=top_liderados_oper,
            top_asist_expres=top_asist_expres,
            top_liderazgos_expres=top_liderazgos_expres,
            top_control_vel=top_control_vel
        )

    @app.route('/member/<int:member_id>/details')
    @login_required
    def member_details_stats(member_id):
        """
        Muestra estadísticas generales para un miembro específico, similares a la tabla de /stats pero solo para él.
        El parámetro member_id corresponde al ID de la tabla companions.
        """
        # Obtener el usuario asociado a este companion
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute(
            "SELECT users.id AS user_id, users.name FROM companions LEFT JOIN users ON companions.name = users.name WHERE companions.id=?",
            (member_id,),
        )
        row = cur.fetchone()
        if not row or not row['user_id']:
            conn.close()
            flash('Miembro no encontrado.', 'warning')
            return redirect(url_for('members'))
        user_id = row['user_id']
        user_name = row['name']
        # Determinar mes actual o parámetro
        month_param = request.args.get('month')
        month = month_param if month_param else datetime.now().strftime('%Y-%m')
        current_dept = session.get('current_department_id')
        # Obtener número de reportes y horas totales del usuario
        if current_dept:
            cur.execute(
                "SELECT COUNT(*) AS num_reports, COALESCE(SUM(duration_hours),0) AS total_hours "
                "FROM reports WHERE user_id=? AND (department_id IS NULL OR department_id=?)",
                (user_id, current_dept),
            )
        else:
            cur.execute(
                "SELECT COUNT(*) AS num_reports, COALESCE(SUM(duration_hours),0) AS total_hours FROM reports WHERE user_id=?",
                (user_id,),
            )
        stats_row = cur.fetchone()
        num_reports = stats_row['num_reports'] if stats_row else 0
        total_hours = stats_row['total_hours'] if stats_row else 0
        # Horas del mes
        if current_dept:
            cur.execute(
                "SELECT COALESCE(SUM(duration_hours),0) AS month_hours FROM reports "
                "WHERE user_id=? AND strftime('%Y-%m', patrol_date)=? AND (department_id IS NULL OR department_id=?)",
                (user_id, month, current_dept),
            )
        else:
            cur.execute(
                "SELECT COALESCE(SUM(duration_hours),0) AS month_hours FROM reports "
                "WHERE user_id=? AND strftime('%Y-%m', patrol_date)=?",
                (user_id, month),
            )
        month_hours_row = cur.fetchone()
        month_hours = month_hours_row['month_hours'] if month_hours_row else 0
        # Informes SP aprobados
        # Considerar sólo informes de la división actual (SP) si corresponde
        if current_dept:
            cur.execute(
                "SELECT COUNT(*) AS num_sp FROM sp_reports WHERE user_id=? AND approved=1 AND department_id=?",
                (user_id, current_dept),
            )
        else:
            cur.execute(
                "SELECT COUNT(*) AS num_sp FROM sp_reports WHERE user_id=? AND approved=1",
                (user_id,),
            )
        sp_row = cur.fetchone()
        num_sp = sp_row['num_sp'] if sp_row else 0
        # Estadísticas manuales
        cur.execute(
            "SELECT * FROM monthly_manual_stats WHERE user_id=? AND month=?",
            (user_id, month),
        )
        manual = cur.fetchone()
        conn.close()
        # Preparar estructura para plantilla
        user_stats = {
            'user_id': user_id,
            'name': user_name,
            'num_reports': num_reports,
            'num_sp_reports': num_sp,
            'total_hours': total_hours,
            'month_hours': month_hours,
        }
        manual_stats = manual if manual else {}
        return render_template('user_stats.html', month=month, user_stats=user_stats, manual_stats=manual_stats, member_id=member_id)

    @app.route('/admin/stats', methods=['GET', 'POST'])
    @login_required
    @admin_required
    def manage_stats():
        """Permite a los administradores editar las estadísticas manuales de cada mes y miembro."""
        month_param = request.args.get('month')
        if month_param:
            month = month_param
        else:
            month = datetime.now().strftime('%Y-%m')
        conn = get_db_connection()
        cur = conn.cursor()
        # Procesar envío
        if request.method == 'POST':
            month_form = request.form.get('month') or month
            # Iterar por cada usuario y actualizar/insertar registros
            cur.execute("SELECT id FROM users")
            user_ids = [u['id'] for u in cur.fetchall()]
            for uid in user_ids:
                asis_op = int(request.form.get(f'asistencia_operativos_{uid}', 0) or 0)
                lid_op = int(request.form.get(f'liderados_operativos_gate_{uid}', 0) or 0)
                asis_ctrl = int(request.form.get(f'asistencia_control_express_{uid}', 0) or 0)
                lid_express = int(request.form.get(f'liderazgos_express_{uid}', 0) or 0)
                ctrl_vel = int(request.form.get(f'control_velocidad_{uid}', 0) or 0)
                # Buscar si existe registro
                cur.execute("SELECT id FROM monthly_manual_stats WHERE user_id=? AND month=?", (uid, month_form))
                row = cur.fetchone()
                if row:
                    cur.execute(
                        "UPDATE monthly_manual_stats SET asistencia_operativos=?, liderados_operativos_gate=?, asistencia_control_express=?, liderazgos_express=?, control_velocidad=? WHERE user_id=? AND month=?",
                        (asis_op, lid_op, asis_ctrl, lid_express, ctrl_vel, uid, month_form),
                    )
                else:
                    cur.execute(
                        "INSERT INTO monthly_manual_stats (user_id, month, asistencia_operativos, liderados_operativos_gate, asistencia_control_express, liderazgos_express, control_velocidad) VALUES (?,?,?,?,?,?,?)",
                        (uid, month_form, asis_op, lid_op, asis_ctrl, lid_express, ctrl_vel),
                    )
            conn.commit()
            flash('Estadísticas actualizadas.', 'success')
            month = month_form
        # Obtener datos automáticos incluyendo acompañantes
        # Pre-cargar usuarios y asignaciones de nombre->id
        cur.execute("SELECT id, name FROM users")
        user_list = cur.fetchall()
        name_to_uid = {}
        for row in user_list:
            if row['name'] not in name_to_uid:
                name_to_uid[row['name']] = row['id']
        # Inicializar acumuladores
        agg = {row['id']: {'user_id': row['id'], 'name': row['name'], 'num_patrols': 0, 'total_hours': 0.0} for row in user_list}
        # Obtener reportes del mes
        cur.execute("SELECT user_id, companions, duration_hours FROM reports WHERE strftime('%Y-%m', patrol_date)=?", (month,))
        rep_rows = cur.fetchall()
        for r in rep_rows:
            if r['user_id'] in agg:
                agg[r['user_id']]['num_patrols'] += 1
                agg[r['user_id']]['total_hours'] += (r['duration_hours'] or 0)
            comps = (r['companions'] or '').split(',') if r['companions'] else []
            for comp in comps:
                comp = comp.strip()
                uid = name_to_uid.get(comp)
                if uid:
                    agg[uid]['num_patrols'] += 1
                    agg[uid]['total_hours'] += (r['duration_hours'] or 0)
        # Convertir a lista ordenada por nombre
        stats_rows = list(agg.values())
        stats_rows.sort(key=lambda x: x['name'])
        # Obtener manual stats
        cur.execute("SELECT * FROM monthly_manual_stats WHERE month=?", (month,))
        manual_rows = cur.fetchall()
        manual_by_user = {row['user_id']: row for row in manual_rows}
        conn.close()
        return render_template('admin_stats.html', stats=stats_rows, manual_by_user=manual_by_user, month=month)

    @app.route('/member/<int:member_id>')
    @login_required
    def member_detail(member_id):
        """Muestra detalles de un miembro específico: perfil, rango y certificaciones."""
        conn = get_db_connection()
        cur = conn.cursor()
        # Obtener datos del compañero y usuario asociado
        cur.execute(
            """
            SELECT companions.name, companions.id AS comp_id, users.id AS user_id, users.profile_image, users.email, users.plate,
                   ranks.name AS rank_name, ranks.description AS rank_description, ranks.patch_image
            FROM companions
            LEFT JOIN users ON companions.name = users.name
            LEFT JOIN ranks ON users.rank_id = ranks.id
            WHERE companions.id=?
            """,
            (member_id,),
        )
        member = cur.fetchone()
        certs = []
        if member and member['user_id']:
            # Obtener certificaciones
            cur.execute(
                """
                SELECT c.id, c.name, c.image
                FROM user_certifications uc
                JOIN certifications c ON uc.certification_id = c.id
                WHERE uc.user_id=?
                """,
                (member['user_id'],),
            )
            certs = cur.fetchall()
            # Estadísticas totales de patrullajes y horas
            cur.execute(
                "SELECT COUNT(id) AS num_patrols, COALESCE(SUM(duration_hours),0) AS total_hours FROM reports WHERE user_id=?",
                (member['user_id'],),
            )
            stats_row = cur.fetchone()
            # Convertir la fila a diccionario para poder usar .get() en las plantillas. Si no hay datos, inicializar valores.
            if stats_row:
                stats = dict(stats_row)
            else:
                stats = {'num_patrols': 0, 'total_hours': 0}
            # Calcular número de Informes SP aprobados para este usuario. Si se está visualizando una
            # división específica (current_department_id), filtrar por esa división; de lo contrario
            # contar todos los informes aprobados.
            current_dept = session.get('current_department_id')
            if current_dept:
                cur.execute(
                    "SELECT COUNT(*) AS c FROM sp_reports WHERE user_id=? AND approved=1 AND department_id=?",
                    (member['user_id'], current_dept),
                )
            else:
                cur.execute(
                    "SELECT COUNT(*) AS c FROM sp_reports WHERE user_id=? AND approved=1",
                    (member['user_id'],),
                )
            sp_count = cur.fetchone()
            stats['num_sp_reports'] = sp_count['c'] if sp_count else 0
            # Horas del mes actual (YYYY-MM)
            month_str = datetime.now().strftime('%Y-%m')
            cur.execute(
                "SELECT COALESCE(SUM(duration_hours),0) AS month_hours FROM reports WHERE user_id=? AND strftime('%Y-%m', patrol_date)=?",
                (member['user_id'], month_str),
            )
            month_hours_row = cur.fetchone()
            month_hours = month_hours_row['month_hours'] if month_hours_row else 0
            # Obtener menciones honoríficas / condecoraciones del usuario
            cur.execute(
                "SELECT id, title, description, image, created_at FROM awards WHERE user_id=? ORDER BY created_at DESC",
                (member['user_id'],),
            )
            honors = cur.fetchall()
        else:
            stats = {'num_patrols': 0, 'total_hours': 0}
            month_hours = 0
            honors = []
        conn.close()
        if not member:
            flash('Miembro no encontrado.', 'warning')
            return redirect(url_for('members'))
        # Ensure that the member object behaves like a dict and includes the companion id
        # sqlite3.Row behaves like a mapping but does not include the rowid by default.
        # Some templates rely on `member['id']` to build URLs; attach the ID manually.
        try:
            # If using sqlite3.Row, keys() returns column names; id may be missing
            if 'id' not in member.keys():
                member_dict = dict(member)
                member_dict['id'] = member_id
                member = member_dict
        except Exception:
            # As fallback, convert to dict and set id
            member = dict(member)
            member['id'] = member_id
        return render_template('member_detail.html', member=member, certs=certs, stats=stats, month_hours=month_hours, honors=honors)

    @app.route('/admin/companions', methods=['GET', 'POST'])
    @login_required
    @admin_required
    def manage_companions():
        """Panel de administración para miembros/acompañantes."""
        conn = get_db_connection()
        cur = conn.cursor()
        if request.method == 'POST':
            action = request.form.get('action')
            if action == 'add':
                name = request.form.get('name', '').strip()
                if name:
                    try:
                        cur.execute("INSERT INTO companions (name) VALUES (?)", (name,))
                        conn.commit()
                        flash('Miembro agregado.', 'success')
                    except sqlite3.IntegrityError:
                        flash('El miembro ya existe.', 'danger')
            elif action == 'delete':
                comp_id = request.form.get('comp_id')
                if comp_id:
                    cur.execute("DELETE FROM companions WHERE id=?", (comp_id,))
                    conn.commit()
                    flash('Miembro eliminado.', 'info')
        cur.execute("SELECT * FROM companions ORDER BY name")
        companions = cur.fetchall()
        conn.close()
        return render_template('admin_companions.html', companions=companions)

    @app.route('/admin/announcements', methods=['GET', 'POST'])
    @login_required
    @admin_required
    def manage_announcements():
        """Panel de administración para anuncios."""
        conn = get_db_connection()
        cur = conn.cursor()
        if request.method == 'POST':
            action = request.form.get('action')
            if action == 'delete':
                ann_id = request.form.get('ann_id')
                if ann_id:
                    cur.execute("DELETE FROM announcements WHERE id=?", (ann_id,))
                    conn.commit()
                    flash('Anuncio eliminado.', 'info')
            elif action == 'update':
                # Actualizar anuncio existente
                ann_id = request.form.get('ann_id')
                title = request.form.get('title', '').strip()
                message = request.form.get('message', '').strip()
                file = request.files.get('image')
                image_filename = None
                if file and file.filename:
                    image_filename = f"announcement_{int(datetime.utcnow().timestamp())}_{file.filename}"
                    file.save(os.path.join(app.config['UPLOAD_FOLDER'], image_filename))
                if ann_id and title and message:
                    if image_filename:
                        cur.execute("UPDATE announcements SET title=?, message=?, image=? WHERE id=?", (title, message, image_filename, ann_id))
                    else:
                        cur.execute("UPDATE announcements SET title=?, message=? WHERE id=?", (title, message, ann_id))
                    conn.commit()
                    flash('Anuncio actualizado.', 'success')
            else:
                # Crear anuncio nuevo
                title = request.form.get('title', '').strip()
                message = request.form.get('message', '').strip()
                file = request.files.get('image')
                image_filename = None
                if file and file.filename:
                    image_filename = f"announcement_{int(datetime.utcnow().timestamp())}_{file.filename}"
                    file.save(os.path.join(app.config['UPLOAD_FOLDER'], image_filename))
                if title and message:
                    dept_id_ann = session.get('current_department_id')
                    cur.execute(
                        "INSERT INTO announcements (title, message, image, department_id) VALUES (?, ?, ?, ?)",
                        (title, message, image_filename, dept_id_ann),
                    )
                    conn.commit()
                    flash('Anuncio creado.', 'success')
        # Filtrar anuncios por departamento salvo que sea administrador global
        current_dept = session.get('current_department_id')
        if session.get('user_role') == 'admin':
            # Staff: si hay división seleccionada, filtrar; sino mostrar todos
            if current_dept:
                cur.execute("SELECT * FROM announcements WHERE department_id=? ORDER BY created_at DESC", (current_dept,))
            else:
                cur.execute("SELECT * FROM announcements ORDER BY created_at DESC")
        else:
            # Cupula o oficial: sólo su departamento
            cur.execute("SELECT * FROM announcements WHERE department_id=? ORDER BY created_at DESC", (current_dept,))
        anns = cur.fetchall()
        conn.close()
        return render_template('admin_announcements.html', announcements=anns)

    @app.route('/members')
    @login_required
    def members():
        """Lista de miembros actuales (acompañantes)."""
        conn = get_db_connection()
        cur = conn.cursor()
        # Unir con usuarios para obtener imágenes de perfil y rangos
        # Obtenemos también una lista concatenada de imágenes de certificaciones por usuario
        # Filtrar miembros por departamento actual si existe
        current_dept = session.get('current_department_id')
        if current_dept:
            # Mostrar solo los miembros asociados al departamento actual
            cur.execute(
                """
                SELECT companions.id, companions.name,
                       users.id AS user_id,
                       users.profile_image,
                       ranks.name AS rank_name,
                       ranks.patch_image,
                       GROUP_CONCAT(certifications.image) AS cert_images
                FROM companions
                LEFT JOIN users ON companions.name = users.name
                LEFT JOIN user_departments ud ON users.id = ud.user_id
                LEFT JOIN ranks ON users.rank_id = ranks.id
                LEFT JOIN user_certifications uc ON users.id = uc.user_id
                LEFT JOIN certifications ON uc.certification_id = certifications.id
                WHERE ud.department_id = ?
                GROUP BY companions.id, companions.name, users.id
                ORDER BY companions.name
                """,
                (current_dept,),
            )
            members_list = cur.fetchall()
        else:
            cur.execute(
                """
                SELECT companions.id, companions.name,
                       users.id AS user_id,
                       users.profile_image,
                       ranks.name AS rank_name,
                       ranks.patch_image,
                       GROUP_CONCAT(certifications.image) AS cert_images
                FROM companions
                LEFT JOIN users ON companions.name = users.name
                LEFT JOIN ranks ON users.rank_id = ranks.id
                LEFT JOIN user_certifications uc ON users.id = uc.user_id
                LEFT JOIN certifications ON uc.certification_id = certifications.id
                GROUP BY companions.id, companions.name, users.id
                ORDER BY companions.name
                """
            )
            members_list = cur.fetchall()
        # Convertir a lista de diccionarios y limpiar imágenes de certificaciones vacías
        members_processed = []
        for row in members_list:
            d = dict(row)
            if d.get('cert_images'):
                # Filtrar elementos vacíos o nulos
                imgs = [img for img in d['cert_images'].split(',') if img]
                d['cert_images'] = ','.join(imgs)
            members_processed.append(d)
        conn.close()
        return render_template('members.html', members=members_processed)

    @app.route('/admin/users', methods=['GET', 'POST'])
    @login_required
    @admin_required
    def manage_users():
        """Interfaz de administración para gestionar usuarios."""
        conn = get_db_connection()
        cur = conn.cursor()
        if request.method == 'POST':
            user_id = request.form.get('user_id')
            action = request.form.get('action')
            if user_id and action:
                # No permitir modificar al superadmin original con username 'admin'
                cur.execute("SELECT username FROM users WHERE id=?", (user_id,))
                target_user = cur.fetchone()
                if target_user and target_user['username'] == 'admin':
                    flash('No se puede modificar la cuenta principal.', 'danger')
                else:
                    # Predefine this variable so it's always available below
                    name_to_remove = None
                    if action == 'approve':
                        # Aprobar usuario y sus asignaciones de departamento
                        cur.execute("UPDATE users SET approved=1 WHERE id=?", (user_id,))
                        cur.execute("UPDATE user_departments SET approved=1 WHERE user_id=?", (user_id,))
                        # Aprobar todos los registros de departamentos asociados
                        cur.execute("UPDATE user_departments SET approved=1 WHERE user_id=?", (user_id,))
                    elif action == 'reject':
                        cur.execute("UPDATE users SET approved=0 WHERE id=?", (user_id,))
                        cur.execute("UPDATE user_departments SET approved=0 WHERE user_id=?", (user_id,))
                        # Rechazar también sus asignaciones de departamento
                        cur.execute("UPDATE user_departments SET approved=0 WHERE user_id=?", (user_id,))
                    elif action == 'promote':
                        cur.execute("UPDATE users SET role='admin' WHERE id=?", (user_id,))
                    elif action == 'demote':
                        cur.execute("UPDATE users SET role='user' WHERE id=?", (user_id,))
                    elif action == 'set_rank':
                        rank_id = request.form.get('rank_id')
                        if rank_id:
                            cur.execute("UPDATE users SET rank_id=? WHERE id=?", (rank_id, user_id))
                    elif action == 'add_cert':
                        # Asignar una certificación a un usuario
                        cert_id = request.form.get('cert_id')
                        if cert_id:
                            # Verificar si ya tiene la certificación
                            cur.execute("SELECT id FROM user_certifications WHERE user_id=? AND certification_id=?", (user_id, cert_id))
                            if not cur.fetchone():
                                cur.execute(
                                    "INSERT INTO user_certifications (user_id, certification_id) VALUES (?, ?)",
                                    (user_id, cert_id),
                                )
                    elif action == 'remove_cert':
                        # Quitar una certificación de un usuario
                        cert_id = request.form.get('cert_id')
                        if cert_id:
                            cur.execute(
                                "DELETE FROM user_certifications WHERE user_id=? AND certification_id=?",
                                (user_id, cert_id),
                            )
                    elif action == 'delete':
                        # Eliminar por completo la cuenta del usuario y todos sus datos relacionados
                        # Recuperar nombre para eliminar de companions
                        cur.execute("SELECT name FROM users WHERE id=?", (user_id,))
                        name_row = cur.fetchone()
                        name_to_remove = name_row['name'] if name_row else None
                        # Eliminar certificaciones
                        cur.execute("DELETE FROM user_certifications WHERE user_id=?", (user_id,))
                        # Eliminar asignaciones de departamento
                        cur.execute("DELETE FROM user_departments WHERE user_id=?", (user_id,))
                        # Eliminar fotos
                        cur.execute("DELETE FROM photos WHERE user_id=?", (user_id,))
                        # Eliminar condecoraciones asignadas
                        cur.execute("DELETE FROM awards WHERE user_id=?", (user_id,))
                        # Eliminar diplomas, menciones honoríficas y notas
                        cur.execute("DELETE FROM diplomas WHERE user_id=?", (user_id,))
                        cur.execute("DELETE FROM honors WHERE user_id=?", (user_id,))
                        cur.execute("DELETE FROM grades WHERE user_id=?", (user_id,))
                        # Eliminar reportes y informes SP
                        cur.execute("DELETE FROM reports WHERE user_id=?", (user_id,))
                        cur.execute("DELETE FROM sp_reports WHERE user_id=?", (user_id,))
                        # Finalmente eliminar usuario
                        cur.execute("DELETE FROM users WHERE id=?", (user_id,))
                        # Eliminar referencias en companions si coincide con su nombre
                        if name_to_remove:
                            cur.execute("DELETE FROM companions WHERE name=?", (name_to_remove,))
                        conn.commit()
                        flash('Usuario y todos sus datos han sido eliminados.', 'info')
                    # Fin de acciones
                    # Para todas las demás acciones, asegúrate de confirmar la transacción y notificar al usuario.
                    if action != 'delete':
                        conn.commit()
                        # Mensaje específico según acción
                        if action == 'approve':
                            flash('Usuario aprobado.', 'success')
                        elif action == 'reject':
                            flash('Usuario suspendido.', 'warning')
                        elif action == 'promote':
                            flash('Usuario promovido a administrador.', 'success')
                        elif action == 'demote':
                            flash('Permisos de administrador revocados.', 'info')
                        elif action == 'set_rank':
                            flash('Rango asignado.', 'success')
                        elif action == 'add_cert':
                            flash('Certificación agregada.', 'success')
                        elif action == 'remove_cert':
                            flash('Certificación eliminada.', 'info')
                        else:
                            flash('Cambios realizados.', 'success')
        # Obtener usuarios junto con su rango
        cur.execute(
            "SELECT users.*, ranks.name AS rank_name FROM users LEFT JOIN ranks ON users.rank_id = ranks.id ORDER BY users.created_at DESC"
        )
        users = cur.fetchall()
        # Obtener rangos para selección
        cur.execute("SELECT id, name FROM ranks ORDER BY id")
        ranks = cur.fetchall()
        # Obtener certificaciones para selección
        cur.execute("SELECT * FROM certifications ORDER BY name")
        certifications = cur.fetchall()
        # Obtener certificaciones asociadas a usuarios
        cur.execute(
            "SELECT uc.user_id, c.id as cert_id, c.name as cert_name, c.image as cert_image FROM user_certifications uc JOIN certifications c ON uc.certification_id = c.id"
        )
        user_certs = cur.fetchall()
        # Organizar certificaciones por usuario
        certs_by_user = {}
        for row in user_certs:
            certs_by_user.setdefault(row['user_id'], []).append(row)
        conn.close()
        return render_template('admin_users.html', users=users, ranks=ranks, certifications=certifications, certs_by_user=certs_by_user)



    @app.route('/admin/user/<int:user_id>')
    @login_required
    @admin_required
    def admin_user_detail(user_id):
        """
        Muestra la información de registro completa de un usuario.
        Solo accesible para administradores globales o cúpula.
        """
        conn = get_db_connection()
        cur = conn.cursor()
        # Obtener datos básicos del usuario
        cur.execute(
            "SELECT * FROM users WHERE id=?",
            (user_id,),
        )
        user = cur.fetchone()
        if not user:
            conn.close()
            flash('Usuario no encontrado.', 'danger')
            return redirect(url_for('manage_users'))
        # Obtener asignaciones a departamentos con roles y flags
        cur.execute(
            "SELECT ud.*, d.name AS dept_name, d.abbreviation AS dept_abbr FROM user_departments ud "
            "JOIN departments d ON ud.department_id = d.id WHERE ud.user_id=?",
            (user_id,),
        )
        dept_assignments = cur.fetchall()
        conn.close()
        return render_template('admin_user_detail.html', user=user, dept_assignments=dept_assignments)

    @app.route('/admin/roles', methods=['GET', 'POST'])
    @login_required
    @admin_required
    def manage_roles():
        """
        Permite que el personal Staff gestione los roles de los usuarios dentro de cada división (cupula, member, community)
        y su rol global (admin o usuario). Solo visible para usuarios con rol global 'admin'.
        """
        conn = get_db_connection()
        cur = conn.cursor()
        # Manejar envíos para actualizar roles y community flags
        if request.method == 'POST':
            ud_id = request.form.get('ud_id')
            new_role = request.form.get('role') or 'member'
            # Checkbox may not be present if unchecked
            community_flag = 1 if request.form.get('community') == 'on' else 0
            if ud_id:
                cur.execute(
                    "UPDATE user_departments SET role=?, community=? WHERE id=?",
                    (new_role, community_flag, ud_id),
                )
                conn.commit()
            # Actualizar rol global si se proporcionó
            global_user_id = request.form.get('global_user_id')
            global_role = request.form.get('global_role')
            if global_user_id and global_role:
                # No permitir degradar al usuario admin original
                cur.execute("SELECT username FROM users WHERE id=?", (global_user_id,))
                row = cur.fetchone()
                if row and row['username'] != 'admin':
                    cur.execute("UPDATE users SET role=? WHERE id=?", (global_role, global_user_id))
                    conn.commit()
        # Obtener las asignaciones de usuario-división junto con datos de usuario y división
        cur.execute(
            "SELECT ud.id AS ud_id, ud.user_id, ud.department_id, ud.role, ud.community, ud.approved, "
            "u.username, u.name AS user_name, u.role AS global_role, d.name AS dept_name, d.abbreviation AS dept_abbr "
            "FROM user_departments ud "
            "JOIN users u ON ud.user_id = u.id "
            "JOIN departments d ON ud.department_id = d.id "
            "ORDER BY u.id, d.id"
        )
        assignments = cur.fetchall()
        conn.close()
        return render_template('admin_roles.html', assignments=assignments)

    @app.route('/profile', methods=['GET', 'POST'])
    @login_required
    def profile():
        """
        Permite al usuario actualizar sus datos de perfil y cargar una imagen.
        """
        conn = get_db_connection()
        cur = conn.cursor()
        user_id = session['user_id']

        if request.method == 'POST':
            name = request.form['name'].strip()
            email = request.form['email'].strip()
            new_password = request.form.get('new_password')
            confirm_password = request.form.get('confirm_password')
            file = request.files.get('profile_image')
            profile_image = None

            if file and file.filename:
                # Guardar imagen de perfil con nombre único
                filename = f"user_{user_id}_{int(datetime.utcnow().timestamp())}_{file.filename}"
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(filepath)
                profile_image = filename

            updates = []
            params = []
            if name:
                updates.append("name=?")
                params.append(name)
            if email:
                updates.append("email=?")
                params.append(email)
            if profile_image:
                updates.append("profile_image=?")
                params.append(profile_image)
            if new_password:
                if new_password != confirm_password:
                    flash('Las contraseñas no coinciden.', 'danger')
                else:
                    updates.append("password=?")
                    params.append(generate_password_hash(new_password))
            if updates:
                query = f"UPDATE users SET {', '.join(updates)} WHERE id=?"
                params.append(user_id)
                cur.execute(query, params)
                conn.commit()
                flash('Perfil actualizado.', 'success')
                # Actualizar datos en sesión
                session['user_name'] = name
                if profile_image:
                    session['profile_image'] = profile_image
            # Guardar preferencia de efectos estacionales (en la sesión)
            # El usuario puede marcar un checkbox disable_effects para desactivar los efectos visuales
            if request.form.get('disable_effects') == 'on':
                session['disable_effects'] = True
            else:
                session.pop('disable_effects', None)
            # Actualizar departamentos del usuario a partir de la selección del formulario
            # Obtener lista de departamentos seleccionados (como ids enteros)
            selected = request.form.getlist('departments')
            selected_ids = set(int(d) for d in selected) if selected else set()
            # Obtener departamentos actuales antes de la actualización
            cur.execute("SELECT department_id FROM user_departments WHERE user_id=?", (user_id,))
            current_depts = set(row['department_id'] for row in cur.fetchall())
            # Departamentos a añadir y eliminar
            to_add = selected_ids - current_depts
            to_remove = current_depts - selected_ids
            # Añadir nuevas relaciones
            for d_id in to_add:
                try:
                    cur.execute(
                        "INSERT INTO user_departments (user_id, department_id, approved) VALUES (?,?,0)",
                        (user_id, d_id),
                    )
                except sqlite3.IntegrityError:
                    pass
            # Eliminar relaciones existentes si el usuario las ha desmarcado
            for d_id in to_remove:
                cur.execute(
                    "DELETE FROM user_departments WHERE user_id=? AND department_id=?",
                    (user_id, d_id),
                )
            if to_add or to_remove:
                conn.commit()
                # Si el usuario ha quitado el departamento actual, forzar selección al primero disponible
                if session.get('current_department_id') in to_remove:
                    # Obtener nueva división del usuario (si existe)
                    cur.execute("SELECT department_id FROM user_departments WHERE user_id=? LIMIT 1", (user_id,))
                    row = cur.fetchone()
                    if row:
                        session['current_department_id'] = row['department_id']
                        # También actualizar abreviatura y nombre en sesión
                        cur.execute("SELECT name, abbreviation, logo FROM departments WHERE id=?", (row['department_id'],))
                        dept = cur.fetchone()
                        if dept:
                            session['current_department_abbr'] = dept['abbreviation']
                            session['current_department_name'] = dept['name']
                            session['current_department_logo'] = dept['logo'] if dept['logo'] else None
        # Obtener datos actualizados de usuario
        cur.execute("SELECT * FROM users WHERE id=?", (user_id,))
        user = cur.fetchone()
        # Obtener lista de departamentos y los del usuario
        cur.execute("SELECT id, name FROM departments ORDER BY name")
        departments = cur.fetchall()
        cur.execute("SELECT department_id FROM user_departments WHERE user_id=?", (user_id,))
        current_depts = [row['department_id'] for row in cur.fetchall()]
        conn.close()
        return render_template('profile.html', user=user, departments=departments, current_depts=current_depts)

    # ------------------------- Galería de fotos -----------------------------
    @app.route('/photos', methods=['GET'])
    @login_required
    def photos():
        """
        Muestra una galería interna de fotos para el usuario autenticado. Se incluyen las fotos públicas,
        las compartidas para todas las divisiones internas y las del propio departamento cuando
        la audiencia sea 'department'. Los administradores globales pueden ver todas las fotos.
        """
        current_dept = session.get('current_department_id')
        conn = get_db_connection()
        cur = conn.cursor()
        # Administrador global (staff) ve todas las fotos
        if session.get('user_role') == 'admin':
            cur.execute(
                "SELECT photos.*, users.name AS uploader_name, departments.abbreviation AS dept_abbr, departments.logo AS dept_logo "
                "FROM photos "
                "LEFT JOIN users ON photos.user_id = users.id "
                "LEFT JOIN departments ON photos.department_id = departments.id "
                "ORDER BY photos.created_at DESC"
            )
        else:
            # Filtrar por audiencia: públicas, internas o de su departamento
            if current_dept:
                cur.execute(
                    "SELECT photos.*, users.name AS uploader_name, departments.abbreviation AS dept_abbr, departments.logo AS dept_logo "
                    "FROM photos "
                    "LEFT JOIN users ON photos.user_id = users.id "
                    "LEFT JOIN departments ON photos.department_id = departments.id "
                    "WHERE photos.audience='public' "
                    "OR photos.audience='internal' "
                    "OR (photos.audience='department' AND photos.department_id=?) "
                    "ORDER BY photos.created_at DESC",
                    (current_dept,),
                )
            else:
                cur.execute(
                    "SELECT photos.*, users.name AS uploader_name, departments.abbreviation AS dept_abbr, departments.logo AS dept_logo "
                    "FROM photos "
                    "LEFT JOIN users ON photos.user_id = users.id "
                    "LEFT JOIN departments ON photos.department_id = departments.id "
                    "WHERE photos.audience='public' OR photos.audience='internal' "
                    "ORDER BY photos.created_at DESC"
                )
        photos_list = [dict(row) for row in cur.fetchall()]
        conn.close()
        # Procesar hashtag/mentions y permisos de eliminación
        tag_filter = request.args.get('tag')
        user_role = session.get('user_role')
        dept_role = session.get('current_dept_role')
        current_dept = session.get('current_department_id')
        filtered = []
        for p in photos_list:
            # Calcular si el usuario puede borrar esta foto
            can_del = False
            try:
                p_dept = p.get('department_id')
            except Exception:
                p_dept = None
            if user_role == 'admin':
                can_del = True
            elif dept_role == 'cupula' and p_dept and current_dept and int(p_dept) == int(current_dept):
                can_del = True
            p['can_delete'] = can_del
            # Resaltar hashtags y menciones; crear enlaces para filtrar
            desc = p.get('description') or ''
            def replace_tag(m):
                text = m.group(0)
                # Remove leading symbols (# or @) to get tag key
                key = text[1:]
                return f'<a href="{ url_for("photos") }?tag={key}" class="text-info fw-semibold">{text}</a>'
            desc_html = re.sub(r'([#@][A-Za-z0-9_]+)', replace_tag, desc)
            p['description_html'] = desc_html
            # Filtrado por tag si corresponde
            if tag_filter:
                # Filtrar por abreviatura
                if p.get('dept_abbr') and p['dept_abbr'].lower() == tag_filter.lower():
                    filtered.append(p)
            else:
                filtered.append(p)
        return render_template('photos.html', photos=filtered, tag_filter=tag_filter)

    # ----------------------------------------------------------------------
    # Rutas de registro y control de informes SP (State Patrol)

    @app.route('/report/sp', methods=['GET', 'POST'])
    @login_required
    def report_sp():
        """Formulario para que los miembros de la State Patrol registren un Informe de Incidencias."""
        # Permitir acceso solo a divisiones de la State Patrol (abreviaturas SP o TSU)
        dept_abbr = session.get('current_department_abbr')
        if dept_abbr not in ('SP', 'TSU'):
            flash('Esta sección está disponible únicamente para la State Patrol.', 'warning')
            return redirect(url_for('dashboard'))
        conn = get_db_connection()
        cur = conn.cursor()
        # Departamento actual
        dept_id = session.get('current_department_id')
        # Obtener unidades disponibles (propias del departamento o globales)
        # Obtener todas las unidades disponibles (número e imagen) para esta división o globales
        cur.execute(
            "SELECT unit_number, image FROM units WHERE department_id=? OR department_id IS NULL ORDER BY unit_number",
            (dept_id,),
        )
        units_list = cur.fetchall()
        # Obtener todos los miembros aprobados de este departamento para el selector de tripulantes
        cur.execute(
            "SELECT u.name FROM users u JOIN user_departments ud ON u.id = ud.user_id WHERE ud.department_id=? AND ud.approved=1 ORDER BY u.name",
            (dept_id,)
        )
        members_list = cur.fetchall()
        # Nombre del usuario actual
        current_user_name = None
        try:
            uid = session.get('user_id')
            if uid:
                cur.execute("SELECT name FROM users WHERE id=?", (uid,))
                row = cur.fetchone()
                if row:
                    current_user_name = row['name']
        except Exception:
            pass
        if request.method == 'POST':
            # Tripulantes recibidos como cadena separada por comas en campo oculto
            trip_raw = request.form.get('tripulantes') or ''
            # Convertir a lista de nombres y limpiar espacios
            selected_trip = [t.strip() for t in trip_raw.split(',') if t.strip()]
            # Garantizar que el nombre del usuario esté incluido al inicio
            if current_user_name and current_user_name not in selected_trip:
                selected_trip.insert(0, current_user_name)
            tripulantes = ', '.join(selected_trip)
            # Unidades seleccionadas (pueden ser múltiples). Se reciben en un campo oculto como CSV.
            units_raw = request.form.get('units') or ''
            selected_units = [u.strip() for u in units_raw.split(',') if u.strip()]
            unit_number = ','.join(selected_units) if selected_units else None
            report_date = request.form.get('report_date')
            report_type = request.form.get('report_type')
            location = request.form.get('location')
            description = request.form.get('description')
            links = request.form.get('links')
            # Imagen o material gráfico: recibimos un enlace (por ejemplo de Imgur) en lugar de archivos
            image_link = request.form.get('image') or request.form.get('images') or None
            # Campos específicos de T-STOP
            stop_vehicle = request.form.get('stop_vehicle') if report_type == 'T-STOP' else None
            stop_person = request.form.get('stop_person') if report_type == 'T-STOP' else None
            stop_mdc = request.form.get('stop_mdc') if report_type == 'T-STOP' else None
            # Insertar en la tabla sp_reports
            cur.execute(
                "INSERT INTO sp_reports (user_id, department_id, tripulantes, unit_number, report_date, report_type, location, description, image, links, stop_vehicle, stop_person, stop_mdc, approved) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,0)",
                (
                    session['user_id'],
                    dept_id,
                    tripulantes,
                    unit_number,
                    report_date,
                    report_type,
                    location,
                    description,
                    image_link,
                    links,
                    stop_vehicle,
                    stop_person,
                    stop_mdc
                ),
            )
            conn.commit()
            conn.close()
            flash('Informe de Incidencias enviado para revisión.', 'success')
            return redirect(url_for('dashboard'))
        current_date = datetime.now().strftime('%Y-%m-%d')
        conn.close()
        return render_template(
            'report_sp.html',
            units_list=units_list,
            current_date=current_date,
            members_list=members_list,
            current_user_name=current_user_name,
        )

    @app.route('/admin/controls', methods=['GET', 'POST'])
    @login_required
    def admin_controls():
        """Panel de control para revisar y aprobar diversos informes y controles."""
        # Permitir acceso a staff o cupula del departamento actual
        role_global = session.get('user_role')
        dept_role = session.get('current_dept_role')
        if role_global != 'admin' and dept_role != 'cupula':
            flash('No tiene permisos para acceder a esta sección.', 'danger')
            return redirect(url_for('dashboard'))
        # Categorías disponibles de informes
        categories = [
            {'key': 'patrol', 'name': 'Informes de patrullaje'},
            {'key': 'sp', 'name': 'Informes de Incidencias'},
            {'key': 'operativo', 'name': 'Control Operativo'},
            {'key': 'radar', 'name': 'Control Radar'},
            {'key': 'expres', 'name': 'Control Exprés'},
            {'key': 'cruce', 'name': 'Control de Cruce'},
            {'key': 'gate', 'name': 'Gate Duty'},
        ]
        selected = request.args.get('type', 'sp')
        conn = get_db_connection()
        cur = conn.cursor()
        # Manejar acciones de aprobación/rechazo para informes SP
        if request.method == 'POST':
            report_id = request.form.get('report_id')
            action = request.form.get('action')
            category = request.form.get('category', 'sp')
            if category == 'sp' and report_id and action:
                if action == 'approve':
                    # Marcar el informe como aprobado
                    cur.execute("UPDATE sp_reports SET approved=1 WHERE id=?", (report_id,))
                    # Obtener autor y tripulantes para notificar
                    cur.execute("SELECT user_id, tripulantes FROM sp_reports WHERE id=?", (report_id,))
                    row_user = cur.fetchone()
                    if row_user:
                        uid = row_user['user_id']
                        # Notificar al autor
                        send_notification(uid, 'Informe de Incidencias aprobado', 'Tu informe ha sido aprobado.', url_for('admin_controls', type='sp'))
                        notified = {uid}
                        # Notificar a tripulantes adicionales
                        trip_field = row_user['tripulantes'] or ''
                        # Abrir nueva conexión para buscar IDs
                        connn = get_db_connection()
                        ccur = connn.cursor()
                        for name in [n.strip() for n in trip_field.split(',') if n.strip()]:
                            ccur.execute("SELECT id FROM users WHERE name=?", (name,))
                            trow = ccur.fetchone()
                            if trow:
                                tid = trow['id']
                                if tid not in notified:
                                    send_notification(tid, 'Informe de Incidencias aprobado', 'Un informe en el que participaste fue aprobado.', url_for('admin_controls', type='sp'))
                                    notified.add(tid)
                        connn.close()
                    flash('Informe de Incidencias aprobado.', 'success')
                elif action == 'reject':
                    # Obtener autor y tripulantes antes de borrar para notificar
                    cur.execute("SELECT user_id, tripulantes FROM sp_reports WHERE id=?", (report_id,))
                    row_user = cur.fetchone()
                    cur.execute("DELETE FROM sp_reports WHERE id=?", (report_id,))
                    if row_user:
                        uid = row_user['user_id']
                        send_notification(uid, 'Informe de Incidencias rechazado', 'Tu informe ha sido rechazado.', url_for('admin_controls', type='sp'))
                        notified = {uid}
                        trip_field = row_user['tripulantes'] or ''
                        connn = get_db_connection()
                        ccur = connn.cursor()
                        for name in [n.strip() for n in trip_field.split(',') if n.strip()]:
                            ccur.execute("SELECT id FROM users WHERE name=?", (name,))
                            trow = ccur.fetchone()
                            if trow:
                                tid = trow['id']
                                if tid not in notified:
                                    send_notification(tid, 'Informe de Incidencias rechazado', 'Un informe en el que participaste fue rechazado.', url_for('admin_controls', type='sp'))
                                    notified.add(tid)
                        connn.close()
                    flash('Informe de Incidencias eliminado.', 'warning')
                conn.commit()
                # Mantener selección después de acción
                selected = 'sp'
        reports = []
        # Obtener informes según categoría seleccionada
        if selected == 'sp':
            if role_global == 'admin':
                cur.execute(
                    "SELECT sp_reports.*, users.name AS user_name FROM sp_reports JOIN users ON sp_reports.user_id=users.id ORDER BY sp_reports.created_at DESC"
                )
            else:
                dept_id = session.get('current_department_id')
                cur.execute(
                    "SELECT sp_reports.*, users.name AS user_name FROM sp_reports JOIN users ON sp_reports.user_id=users.id WHERE sp_reports.department_id=? ORDER BY sp_reports.created_at DESC",
                    (dept_id,),
                )
            reports = cur.fetchall()
        elif selected == 'patrol':
            # Mostrar informes de patrullaje (tabla reports). Actualmente no hay flujo de aprobación para patrullajes, por lo que solo se muestran.
            if role_global == 'admin':
                cur.execute(
                    "SELECT reports.*, users.name AS user_name FROM reports JOIN users ON reports.user_id=users.id ORDER BY reports.created_at DESC"
                )
            else:
                dept_id = session.get('current_department_id')
                cur.execute(
                    "SELECT reports.*, users.name AS user_name FROM reports JOIN users ON reports.user_id=users.id WHERE reports.department_id IS NULL OR reports.department_id=? ORDER BY reports.created_at DESC",
                    (dept_id,),
                )
            reports = cur.fetchall()
        else:
            # Para las demás categorías aún no hay tablas específicas; dejar la lista vacía
            reports = []
        conn.close()
        return render_template('admin_controls.html', categories=categories, selected=selected, reports=reports)

    # ------------------------------------------------------------------
    # Vista detallada de informe de incidencias para administradores
    @app.route('/admin/incident/<int:report_id>', methods=['GET', 'POST'])
    @login_required
    def admin_incident_detail(report_id):
        """Muestra los detalles completos de un informe de incidencias (SP) y permite aprobar, rechazar o comentar.

        Accesible solo para administradores globales o cúpula de la división correspondiente. Si se
        invoca mediante POST para aprobar o rechazar, redirige nuevamente al panel de control.
        """
        # Verificar permisos
        role_global = session.get('user_role')
        dept_role = session.get('current_dept_role')
        if role_global != 'admin' and dept_role != 'cupula':
            flash('No tiene permisos para acceder a esta sección.', 'danger')
            return redirect(url_for('dashboard'))
        conn = get_db_connection()
        cur = conn.cursor()
        # Manejar acciones de aprobación o rechazo desde el detalle
        if request.method == 'POST':
            action = request.form.get('action')
            if action in ['approve', 'reject']:
                if action == 'approve':
                    # Marcar informe como aprobado
                    cur.execute("UPDATE sp_reports SET approved=1 WHERE id=?", (report_id,))
                    # Obtener autor y tripulantes para notificar
                    cur.execute("SELECT user_id, tripulantes FROM sp_reports WHERE id=?", (report_id,))
                    row_user = cur.fetchone()
                    if row_user:
                        uid = row_user['user_id']
                        send_notification(uid, 'Informe de Incidencias aprobado', 'Tu informe ha sido aprobado.', url_for('admin_controls', type='sp'))
                        notified = {uid}
                        trip_field = row_user['tripulantes'] or ''
                        connn = get_db_connection()
                        ccur = connn.cursor()
                        for name in [n.strip() for n in trip_field.split(',') if n.strip()]:
                            ccur.execute("SELECT id FROM users WHERE name=?", (name,))
                            trow = ccur.fetchone()
                            if trow:
                                tid = trow['id']
                                if tid not in notified:
                                    send_notification(tid, 'Informe de Incidencias aprobado', 'Un informe en el que participaste fue aprobado.', url_for('admin_controls', type='sp'))
                                    notified.add(tid)
                        connn.close()
                    flash('Informe de Incidencias aprobado.', 'success')
                elif action == 'reject':
                    cur.execute("SELECT user_id, tripulantes FROM sp_reports WHERE id=?", (report_id,))
                    row_user = cur.fetchone()
                    cur.execute("DELETE FROM sp_reports WHERE id=?", (report_id,))
                    if row_user:
                        uid = row_user['user_id']
                        send_notification(uid, 'Informe de Incidencias rechazado', 'Tu informe ha sido rechazado.', url_for('admin_controls', type='sp'))
                        notified = {uid}
                        trip_field = row_user['tripulantes'] or ''
                        connn = get_db_connection()
                        ccur = connn.cursor()
                        for name in [n.strip() for n in trip_field.split(',') if n.strip()]:
                            ccur.execute("SELECT id FROM users WHERE name=?", (name,))
                            trow = ccur.fetchone()
                            if trow:
                                tid = trow['id']
                                if tid not in notified:
                                    send_notification(tid, 'Informe de Incidencias rechazado', 'Un informe en el que participaste fue rechazado.', url_for('admin_controls', type='sp'))
                                    notified.add(tid)
                        connn.close()
                    flash('Informe de Incidencias eliminado.', 'warning')
                conn.commit()
                conn.close()
                return redirect(url_for('admin_controls', type='sp'))
        # Obtener datos del informe
        cur.execute("SELECT sp_reports.*, users.name AS user_name FROM sp_reports JOIN users ON sp_reports.user_id=users.id WHERE sp_reports.id=?", (report_id,))
        report = cur.fetchone()
        if not report:
            conn.close()
            flash('Informe no encontrado.', 'warning')
            return redirect(url_for('admin_controls', type='sp'))
        # Obtener unidades e imágenes de cada unidad
        units_raw = report['unit_number'] or ''
        unit_numbers = [u.strip() for u in units_raw.split(',') if u.strip()]
        unit_infos = []
        for num in unit_numbers:
            cur.execute("SELECT unit_number, image FROM units WHERE unit_number=?", (num,))
            row_u = cur.fetchone()
            if row_u:
                unit_infos.append(dict(row_u))
            else:
                unit_infos.append({'unit_number': num, 'image': None})
        # Obtener tripulantes
        trip_raw = report['tripulantes'] or ''
        tripulantes = [t.strip() for t in trip_raw.split(',') if t.strip()]
        # Obtener comentarios
        cur.execute(
            "SELECT c.*, u.name AS user_name FROM sp_report_comments c JOIN users u ON c.user_id=u.id WHERE c.report_id=? ORDER BY c.created_at ASC",
            (report_id,)
        )
        comments = cur.fetchall()
        conn.close()
        return render_template('admin_incident_detail.html', report=report, units=unit_infos, tripulantes=tripulantes, comments=comments)

    # ----------------------------------------------------------------------
    # Calendario de controles y actividades

    @app.route('/calendar', methods=['GET', 'POST'])
    @login_required
    def calendar_view():
        """Muestra el calendario de eventos programados y permite crear nuevos eventos."""
        conn = get_db_connection()
        cur = conn.cursor()
        dept_id = session.get('current_department_id')
        # Si se envía un formulario para crear un nuevo evento
        if request.method == 'POST':
            title = request.form.get('title', '').strip()
            description = request.form.get('description', '').strip()
            start_datetime = request.form.get('start_datetime')
            end_datetime = request.form.get('end_datetime')
            control_type = request.form.get('control_type', '').strip()
            location = request.form.get('location', '').strip()
            units_required = request.form.get('units_required', '').strip()
            invited_departments = ','.join(request.form.getlist('invited_departments')) if request.form.getlist('invited_departments') else None
            banner_file = request.files.get('banner')
            banner_filename = None
            if banner_file and banner_file.filename:
                filename = secure_filename(banner_file.filename)
                fname = f"event_{int(datetime.now().timestamp())}_{filename}"
                banner_file.save(os.path.join(app.root_path, 'static', 'uploads', fname))
                banner_filename = fname
            if title and start_datetime:
                cur.execute(
                    "INSERT INTO events (user_id, department_id, title, description, start_datetime, end_datetime, control_type, location, units_required, invited_departments, banner) "
                    "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                    (
                        session['user_id'],
                        dept_id,
                        title,
                        description,
                        start_datetime,
                        end_datetime,
                        control_type,
                        location,
                        units_required,
                        invited_departments,
                        banner_filename,
                    ),
                )
                conn.commit()
                flash('Evento creado correctamente.', 'success')
            return redirect(url_for('calendar_view'))

        # Determinar el mes a mostrar en formato YYYY-MM
        month_param = request.args.get('month')
        if month_param:
            try:
                display_date = datetime.strptime(month_param, '%Y-%m')
            except Exception:
                display_date = datetime.now()
        else:
            display_date = datetime.now()
        year = display_date.year
        month = display_date.month
        # Obtener eventos del departamento, globales y por invitación
        if dept_id:
            cur.execute(
                "SELECT e.*, u.name AS user_name, d.name AS dept_name FROM events e "
                "LEFT JOIN users u ON e.user_id=u.id "
                "LEFT JOIN departments d ON e.department_id=d.id "
                "WHERE e.department_id IS NULL OR e.department_id=? OR (e.invited_departments LIKE '%' || ? || '%')",
                (dept_id, session.get('current_department_abbr', '')),
            )
        else:
            cur.execute(
                "SELECT e.*, u.name AS user_name, d.name AS dept_name FROM events e "
                "LEFT JOIN users u ON e.user_id=u.id "
                "LEFT JOIN departments d ON e.department_id=d.id "
            )
        rows = cur.fetchall()
        events = []
        # Agrupar eventos por fecha y calcular tiempo restante
        events_by_date = {}
        now = datetime.now()
        for row in rows:
            ev = dict(row)
            # Parse start date; proteger si es None o vacío
            start_raw = ev.get('start_datetime')
            if start_raw:
                try:
                    if 'T' in start_raw:
                        start_dt = datetime.strptime(start_raw, '%Y-%m-%dT%H:%M')
                    else:
                        start_dt = datetime.strptime(start_raw, '%Y-%m-%d %H:%M:%S')
                except Exception:
                    start_dt = None
            else:
                start_dt = None
            # Calcular tiempo restante para mostrar
            if start_dt:
                diff = start_dt - now
                if diff.total_seconds() > 0:
                    days = diff.days
                    hours = diff.seconds // 3600
                    if days > 0:
                        ev['time_until'] = f"{days}d {hours}h"
                    elif hours > 0:
                        minutes = (diff.seconds % 3600) // 60
                        ev['time_until'] = f"{hours}h {minutes}m"
                    else:
                        minutes = diff.seconds // 60
                        ev['time_until'] = f"{minutes}m"
                else:
                    ev['time_until'] = 'En curso'
            else:
                ev['time_until'] = ''
            # Agrupar por fecha (YYYY-MM-DD)
            if start_dt:
                date_key = start_dt.date().isoformat()
                events_by_date.setdefault(date_key, []).append(ev)
            events.append(ev)
        # Generar estructura de calendario para el mes seleccionado
        # Generate the month matrix using pycal (alias for calendar)
        month_calendar = pycal.monthcalendar(year, month)
        month_name = datetime(year, month, 1).strftime('%B')
        # Convertir nombre de mes a español (manual para mayor claridad)
        months_es = {
            'January': 'Enero', 'February': 'Febrero', 'March': 'Marzo', 'April': 'Abril',
            'May': 'Mayo', 'June': 'Junio', 'July': 'Julio', 'August': 'Agosto',
            'September': 'Septiembre', 'October': 'Octubre', 'November': 'Noviembre', 'December': 'Diciembre'
        }
        month_name_es = months_es.get(month_name, month_name)
        # Calcular los parámetros de navegación (mes anterior y siguiente)
        prev_month = (display_date - timedelta(days=1)).strftime('%Y-%m')
        next_month = (display_date + timedelta(days=31)).strftime('%Y-%m')
        # Obtener lista de departamentos para invitaciones en el formulario
        cur.execute("SELECT id, name, abbreviation FROM departments")
        departments = cur.fetchall()
        conn.close()
        return render_template(
            'calendar.html',
            events_by_date=events_by_date,
            month_calendar=month_calendar,
            month_name=month_name_es,
            year=year,
            month=month,
            prev_month=prev_month,
            next_month=next_month,
            departments=departments
        )

    @app.route('/event/<int:event_id>')
    @login_required
    def event_detail(event_id):
        """Muestra detalles de un evento específico del calendario."""
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute(
            "SELECT e.*, u.name AS user_name, d.name AS dept_name FROM events e "
            "LEFT JOIN users u ON e.user_id=u.id "
            "LEFT JOIN departments d ON e.department_id=d.id "
            "WHERE e.id=?",
            (event_id,)
        )
        ev = cur.fetchone()
        conn.close()
        if not ev:
            flash('Evento no encontrado.', 'warning')
            return redirect(url_for('calendar_view'))
        return render_template('event_detail.html', event=ev)

    @app.route('/certification/<int:cert_id>')
    @login_required
    def certification_detail(cert_id):
        """Muestra detalles de una certificación."""
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM certifications WHERE id=?", (cert_id,))
        cert = cur.fetchone()
        conn.close()
        if not cert:
            flash('Certificación no encontrada.', 'danger')
            return redirect(url_for('dashboard'))
        return render_template('cert_detail.html', cert=cert)

    @app.route('/honor/<int:honor_id>')
    @login_required
    def honor_detail(honor_id):
        """Muestra detalles de una mención honorífica."""
        conn = get_db_connection()
        cur = conn.cursor()
        # Intentar obtener la mención honorífica desde la tabla 'honors'
        cur.execute("SELECT * FROM honors WHERE id=?", (honor_id,))
        honor = cur.fetchone()
        # Si no se encuentra en 'honors', comprobar si existe en 'awards'
        # Algunas menciones pueden haberse almacenado como condecoraciones en la tabla awards
        if not honor:
            cur.execute("SELECT * FROM awards WHERE id=?", (honor_id,))
            award = cur.fetchone()
            conn.close()
            if award:
                # Redirigir a la vista de condecoración para mostrarla
                return redirect(url_for('award_detail', award_id=honor_id))
            flash('Mención no encontrada.', 'danger')
            return redirect(url_for('dashboard'))
        conn.close()
        return render_template('honor_detail.html', honor=honor)

    @app.route('/award/<int:award_id>')
    @login_required
    def award_detail(award_id):
        """
        Muestra detalles de una condecoración asignada o definida. Incluye
        la descripción completa, la imagen, la fecha de creación y un listado
        de otros usuarios que han recibido la misma condecoración (mismo título).
        """
        conn = get_db_connection()
        cur = conn.cursor()
        # Obtener la condecoración por id
        cur.execute("SELECT a.*, u.name AS user_name, d.name AS dept_name FROM awards a "
                    "LEFT JOIN users u ON a.user_id=u.id "
                    "LEFT JOIN departments d ON a.department_id=d.id "
                    "WHERE a.id=?", (award_id,))
        award = cur.fetchone()
        if not award:
            conn.close()
            flash('Condecoración no encontrada.', 'danger')
            return redirect(url_for('dashboard'))
        # Obtener lista de receptores de la misma condecoración (mismo título) excluyendo definiciones
        cur.execute(
            "SELECT u.name FROM awards a JOIN users u ON a.user_id=u.id WHERE a.title=? AND a.user_id IS NOT NULL ORDER BY u.name",
            (award['title'],)
        )
        recipients = [row['name'] for row in cur.fetchall()]
        conn.close()
        return render_template('award_detail.html', award=award, recipients=recipients)

    @app.route('/photos/new', methods=['GET', 'POST'])
    @login_required
    def new_photo():
        """
        Permite a cualquier usuario subir una imagen. El usuario puede elegir la audiencia de la foto. 
        Solo los usuarios con privilegio de comunidad (community) o rol global de staff pueden seleccionar
        "público general" como audiencia. Las demás audiencias se limitan a su división o a todas las divisiones internas.
        """
        # Determinar permisos de publicación para audiencias
        # allow_public: permite seleccionar público general
        # allow_internal: permite seleccionar todas las divisiones (interno)
        allow_public = False
        allow_internal = False
        if session.get('user_role') == 'admin':
            # Staff puede publicar tanto a todas las divisiones como al público
            allow_public = True
            allow_internal = True
        else:
            user_id = session.get('user_id')
            dept_id = session.get('current_department_id')
            if user_id and dept_id:
                conn_check = get_db_connection()
                cur_check = conn_check.cursor()
                cur_check.execute(
                    "SELECT community, role FROM user_departments WHERE user_id=? AND department_id=? AND approved=1",
                    (user_id, dept_id),
                )
                row = cur_check.fetchone()
                conn_check.close()
                if row:
                    # Cúpula y comunidad pueden publicar público; comunidad y cúpula permiten interno para todas las divisiones
                    if row['role'] == 'cupula' or bool(row['community']):
                        allow_public = True
                        allow_internal = True
        if request.method == 'POST':
            image_file = request.files.get('image')
            description = request.form.get('description', '').strip()
            audience = request.form.get('audience', 'department')
            if not image_file or image_file.filename == '':
                flash('Debe seleccionar una imagen.', 'warning')
                return redirect(request.url)
            # Validar audiencia contra permisos
            if audience == 'public' and not allow_public:
                flash('No tiene permisos para publicar imágenes al público.', 'danger')
                return redirect(request.url)
            if audience == 'internal' and not allow_internal:
                flash('No tiene permisos para publicar imágenes a todas las divisiones.', 'danger')
                return redirect(request.url)
            # Guardar la imagen en la carpeta de uploads con un nombre único
            import time
            filename = image_file.filename
            prefix = f"{int(time.time())}_{session.get('user_id')}_"
            secure_name = prefix + filename
            save_path = os.path.join(app.config['UPLOAD_FOLDER'], secure_name)
            image_file.save(save_path)
            # Determinar departamento de la imagen. Siempre asociamos la foto al departamento
            # de origen para poder mostrar su logo aunque la audiencia sea 'internal' o 'public'.
            dept_val = session.get('current_department_id')
            # Guardar registro en base de datos
            conn = get_db_connection()
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO photos (user_id, department_id, description, image, audience) VALUES (?, ?, ?, ?, ?)",
                (session.get('user_id'), dept_val, description, secure_name, audience),
            )
            conn.commit()
            conn.close()
            flash('Imagen publicada correctamente.', 'success')
            return redirect(url_for('photos'))
        return render_template('new_photo.html', allow_public=allow_public, allow_internal=allow_internal)

    @app.route('/gallery', methods=['GET'])
    def gallery():
        """
        Galería pública accesible sin iniciar sesión. Muestra únicamente las fotos con audiencia 'public'.
        """
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute(
            "SELECT photos.*, users.name AS uploader_name, departments.abbreviation AS dept_abbr, departments.logo AS dept_logo "
            "FROM photos "
            "LEFT JOIN users ON photos.user_id = users.id "
            "LEFT JOIN departments ON photos.department_id = departments.id "
            "WHERE photos.audience='public' "
            "ORDER BY photos.created_at DESC"
        )
        photos_list = [dict(row) for row in cur.fetchall()]
        conn.close()
        tag_filter = request.args.get('tag')
        filtered = []
        for p in photos_list:
            # procesar hashtags en la descripción
            desc = p.get('description') or ''
            def replace_tag(m):
                text = m.group(0)
                key = text[1:]
                return f'<a href="{ url_for("gallery") }?tag={key}" class="text-info fw-semibold">{text}</a>'
            desc_html = re.sub(r'([#@][A-Za-z0-9_]+)', replace_tag, desc)
            p['description_html'] = desc_html
            # filtrar por abreviatura si se solicita
            if tag_filter:
                if p.get('dept_abbr') and p['dept_abbr'].lower() == tag_filter.lower():
                    filtered.append(p)
            else:
                filtered.append(p)
        return render_template('gallery.html', photos=filtered, tag_filter=tag_filter)

    @app.route('/photo/<int:photo_id>/delete', methods=['POST'])
    @login_required
    def delete_photo(photo_id):
        """
        Elimina una foto de la galería. Solo está permitido para el personal con rol de cúpula en la división
        correspondiente o para administradores globales. Las fotos públicas y de otras divisiones no pueden ser
        eliminadas por usuarios de cúpula de otra división.
        """
        conn = get_db_connection()
        cur = conn.cursor()
        # Recuperar foto
        cur.execute("SELECT * FROM photos WHERE id=?", (photo_id,))
        photo = cur.fetchone()
        if not photo:
            conn.close()
            flash('Foto no encontrada.', 'warning')
            return redirect(url_for('photos'))
        # Verificar permisos
        user_role = session.get('user_role')
        dept_role = session.get('current_dept_role')
        current_dept = session.get('current_department_id')
        allowed = False
        if user_role == 'admin':
            allowed = True
        elif dept_role == 'cupula' and photo['department_id'] and current_dept and int(photo['department_id']) == int(current_dept):
            allowed = True
        if not allowed:
            conn.close()
            flash('No tienes permiso para eliminar esta foto.', 'danger')
            return redirect(url_for('photos'))
        # Eliminar archivo físico si existe
        image_path = photo['image']
        if image_path:
            try:
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], image_path)
                if os.path.exists(file_path):
                    os.remove(file_path)
            except Exception:
                pass
        # Eliminar registro
        cur.execute("DELETE FROM photos WHERE id=?", (photo_id,))
        conn.commit()
        conn.close()
        flash('Foto eliminada correctamente.', 'info')
        return redirect(url_for('photos'))

    # ---------------------- Secciones académicas ----------------------

    def fetch_department_users(dept_id):
        """Devuelve usuarios aprobados de una división para seleccionarlos en formularios."""
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute(
            "SELECT u.id, u.name FROM users u JOIN user_departments ud ON ud.user_id=u.id WHERE ud.department_id=? AND ud.approved=1 ORDER BY u.name",
            (dept_id,),
        )
        rows = cur.fetchall()
        conn.close()
        return rows

    @app.route('/academics/diplomas', methods=['GET','POST'])
    @login_required
    def academics_diplomas():
        """Muestra y permite gestionar diplomas académicos de la división actual."""
        dept_id = session.get('current_department_id')
        role_global = session.get('user_role')
        dept_role = session.get('current_dept_role')
        can_manage = (role_global == 'admin' or dept_role == 'cupula')
        allow_global_award = (role_global == 'admin')
        conn = get_db_connection()
        cur = conn.cursor()
        if request.method == 'POST' and can_manage:
            action = request.form.get('action', 'add')
            if action == 'delete':
                diploma_id = request.form.get('diploma_id')
                if diploma_id:
                    cur.execute("DELETE FROM diplomas WHERE id=?", (diploma_id,))
                    conn.commit()
                    flash('Diploma eliminado correctamente.', 'success')
            else:
                user_id = request.form.get('user_id') or None
                title = request.form.get('title','').strip()
                description = request.form.get('description','').strip()
                audience = request.form.get('audience','department')
                file = request.files.get('image')
                image_filename = None
                if file and file.filename:
                    image_filename = f"diploma_{int(datetime.utcnow().timestamp())}_{secure_filename(file.filename)}"
                    file.save(os.path.join(app.config['UPLOAD_FOLDER'], image_filename))
                # Solo los administradores globales pueden crear diplomas para todos los departamentos
                dept_target = None if (audience == 'all' and allow_global_award) else dept_id
                cur.execute(
                    "INSERT INTO diplomas (user_id, title, description, image, department_id, audience) VALUES (?,?,?,?,?,?)",
                    (user_id, title, description, image_filename, dept_target, audience),
                )
                conn.commit()
                flash('Diploma agregado correctamente.', 'success')
        # Obtener diplomas visibles: propios de la división o globales. Permite filtrar por usuario mediante parámetro user_id
        user_filter = request.args.get('user_id')
        if user_filter:
            cur.execute(
                "SELECT d.*, u.name AS user_name, de.abbreviation AS dept_abbr, de.logo AS dept_logo "
                "FROM diplomas d "
                "LEFT JOIN users u ON d.user_id = u.id "
                "LEFT JOIN departments de ON d.department_id = de.id "
                "WHERE (d.department_id IS NULL OR d.department_id = ? OR d.audience='all') AND d.user_id=? "
                "ORDER BY d.created_at DESC",
                (dept_id, user_filter),
            )
        else:
            cur.execute(
                "SELECT d.*, u.name AS user_name, de.abbreviation AS dept_abbr, de.logo AS dept_logo "
                "FROM diplomas d "
                "LEFT JOIN users u ON d.user_id = u.id "
                "LEFT JOIN departments de ON d.department_id = de.id "
                "WHERE (d.department_id IS NULL OR d.department_id = ? OR d.audience='all') "
                "ORDER BY d.created_at DESC",
                (dept_id,),
            )
        diplomas = [dict(row) for row in cur.fetchall()]
        users_list = fetch_department_users(dept_id)
        conn.close()
        return render_template('academics_diplomas.html', diplomas=diplomas, users_list=users_list, can_manage=can_manage, allow_global_award=allow_global_award)

    @app.route('/academics/honors', methods=['GET','POST'])
    @login_required
    def academics_honors():
        """Muestra y permite gestionar menciones honoríficas de la división actual."""
        dept_id = session.get('current_department_id')
        role_global = session.get('user_role')
        dept_role = session.get('current_dept_role')
        can_manage = (role_global == 'admin' or dept_role == 'cupula')
        allow_global_award = (role_global == 'admin')
        conn = get_db_connection()
        cur = conn.cursor()
        if request.method == 'POST' and can_manage:
            action = request.form.get('action', 'create')
            if action == 'delete':
                # Eliminar mención por ID
                honor_id = request.form.get('honor_id')
                if honor_id:
                    cur.execute("DELETE FROM honors WHERE id=?", (honor_id,))
                    conn.commit()
                    flash('Mención eliminada correctamente.', 'info')
            else:
                # Crear nueva mención
                user_id = request.form.get('user_id') or None
                title = request.form.get('title','').strip()
                description = request.form.get('description','').strip()
                audience = request.form.get('audience','department')
                file = request.files.get('image')
                image_filename = None
                if file and file.filename:
                    image_filename = f"honor_{int(datetime.utcnow().timestamp())}_{file.filename}"
                    file.save(os.path.join(app.config['UPLOAD_FOLDER'], image_filename))
                dept_target = None if (audience == 'all' and allow_global_award) else dept_id
                cur.execute(
                    "INSERT INTO honors (user_id, title, description, image, department_id, audience) VALUES (?,?,?,?,?,?)",
                    (user_id, title, description, image_filename, dept_target, audience),
                )
                conn.commit()
                flash('Mención honorífica agregada correctamente.', 'success')
        # Obtener menciones visibles. Permite filtrar por usuario con parámetro user_id
        user_filter = request.args.get('user_id')
        if user_filter:
            cur.execute(
                "SELECT h.*, u.name AS user_name, de.abbreviation AS dept_abbr, de.logo AS dept_logo "
                "FROM honors h "
                "LEFT JOIN users u ON h.user_id = u.id "
                "LEFT JOIN departments de ON h.department_id = de.id "
                "WHERE (h.department_id IS NULL OR h.department_id = ? OR h.audience='all') AND h.user_id=? "
                "ORDER BY h.created_at DESC",
                (dept_id, user_filter),
            )
        else:
            cur.execute(
                "SELECT h.*, u.name AS user_name, de.abbreviation AS dept_abbr, de.logo AS dept_logo "
                "FROM honors h "
                "LEFT JOIN users u ON h.user_id = u.id "
                "LEFT JOIN departments de ON h.department_id = de.id "
                "WHERE (h.department_id IS NULL OR h.department_id = ? OR h.audience='all') "
                "ORDER BY h.created_at DESC",
                (dept_id,),
            )
        honors = [dict(row) for row in cur.fetchall()]
        users_list = fetch_department_users(dept_id)
        conn.close()
        return render_template('academics_honors.html', honors=honors, users_list=users_list, can_manage=can_manage, allow_global_award=allow_global_award)

    @app.route('/academics/grades', methods=['GET','POST'])
    @login_required
    def academics_grades():
        """Muestra y permite gestionar el registro de notas para la división actual. Solo accesible a cúpula o staff."""
        dept_id = session.get('current_department_id')
        role_global = session.get('user_role')
        dept_role = session.get('current_dept_role')
        can_manage = (role_global == 'admin' or dept_role == 'cupula')
        if not can_manage:
            flash('No tienes permisos para ver el registro de notas.', 'danger')
            return redirect(url_for('dashboard'))
        conn = get_db_connection()
        cur = conn.cursor()
        if request.method == 'POST':
            # Actualizar registros existentes
            # Para cada grado actual en la base de datos, procesar campos de formulario con sufijo del ID
            cur.execute(
                "SELECT id FROM grades WHERE department_id=?",
                (dept_id,)
            )
            existing_ids = [row['id'] for row in cur.fetchall()]
            for gid in existing_ids:
                # Campos de actualización
                date = request.form.get(f'date_{gid}')
                subject = request.form.get(f'subject_{gid}','').strip()
                grade_val = request.form.get(f'grade_{gid}','').strip()
                notes = request.form.get(f'notes_{gid}','').strip()
                can_patrol = request.form.get(f'can_patrol_{gid}','').strip() or None
                pit_cert = request.form.get(f'pit_cert_{gid}','').strip() or None
                theoretical_grade = request.form.get(f'theoretical_grade_{gid}','').strip() or None
                card_status = request.form.get(f'card_status_{gid}','').strip() or None
                card_grade1 = request.form.get(f'card_grade1_{gid}','').strip() or None
                card_grade2 = request.form.get(f'card_grade2_{gid}','').strip() or None
                double_promotion = request.form.get(f'double_promotion_{gid}','').strip() or None
                # Realizar actualización solo si campos obligatorios existen
                if date and subject and grade_val:
                    cur.execute(
                        "UPDATE grades SET date=?, subject=?, grade=?, notes=?, can_patrol=?, pit_cert=?, theoretical_grade=?, card_status=?, card_grade1=?, card_grade2=?, double_promotion=? WHERE id=?",
                        (date, subject, grade_val, notes, can_patrol, pit_cert, theoretical_grade, card_status, card_grade1, card_grade2, double_promotion, gid),
                    )
            # Insertar nuevo registro si se proporcionaron campos
            new_user_id = request.form.get('new_user_id')
            new_date = request.form.get('new_date')
            new_subject = request.form.get('new_subject','').strip()
            new_grade = request.form.get('new_grade','').strip()
            new_notes = request.form.get('new_notes','').strip()
            new_can_patrol = request.form.get('new_can_patrol','').strip() or None
            new_pit_cert = request.form.get('new_pit_cert','').strip() or None
            new_theoretical = request.form.get('new_theoretical_grade','').strip() or None
            new_card_status = request.form.get('new_card_status','').strip() or None
            new_card_grade1 = request.form.get('new_card_grade1','').strip() or None
            new_card_grade2 = request.form.get('new_card_grade2','').strip() or None
            new_double = request.form.get('new_double_promotion','').strip() or None
            if new_user_id and new_date and new_subject and new_grade:
                cur.execute(
                    "INSERT INTO grades (user_id, date, subject, grade, notes, department_id, can_patrol, pit_cert, theoretical_grade, card_status, card_grade1, card_grade2, double_promotion) "
                    "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (
                        new_user_id,
                        new_date,
                        new_subject,
                        new_grade,
                        new_notes,
                        dept_id,
                        new_can_patrol,
                        new_pit_cert,
                        new_theoretical,
                        new_card_status,
                        new_card_grade1,
                        new_card_grade2,
                        new_double,
                    ),
                )
            conn.commit()
            flash('Registros académicos actualizados.', 'success')
        cur.execute(
            "SELECT g.*, u.name AS user_name, r.name AS rank_name FROM grades g "
            "JOIN users u ON g.user_id=u.id "
            "LEFT JOIN ranks r ON u.rank_id = r.id "
            "WHERE g.department_id=? ORDER BY g.date DESC",
            (dept_id,),
        )
        grades = [dict(row) for row in cur.fetchall()]
        # Filtrar usuarios para la lista: solo cadetes de esta división
        # Obtener usuarios con rango "State Trooper Cadet" (antiguo Traffic Officer Cadet) dentro del departamento
        cur.execute(
            "SELECT u.id, u.name FROM users u "
            "JOIN user_departments ud ON u.id = ud.user_id "
            "JOIN ranks r ON u.rank_id = r.id "
            "WHERE ud.department_id=? AND ud.approved=1 AND (r.name LIKE 'State Trooper Cadet' OR r.name LIKE 'Traffic Officer Cadet')",
            (dept_id,)
        )
        users_list = cur.fetchall()
        conn.close()
        return render_template('academics_grades.html', grades=grades, users_list=users_list, can_manage=can_manage)

    @app.route('/hall_of_fame')
    def hall_of_fame():
        """Muro de la fama: muestra diplomas, menciones y condecoraciones globales.

        Esta vista agrega tolerancia a valores nulos o ausentes en la base de datos
        para evitar errores 500. Las filas se completan con valores por defecto
        cuando ciertas columnas (como logo de departamento o descripción) están vacías.
        """
        conn = get_db_connection()
        cur = conn.cursor()
        items = []
        # Diplomas globales: se muestran diplomas asignados a todos los departamentos o sin departamento
        cur.execute(
            "SELECT 'Diploma' AS type, d.title, d.description, d.image, d.created_at AS created_at, "
            "u.name AS user_name, de.abbreviation AS dept_abbr, de.logo AS dept_logo "
            "FROM diplomas d "
            "LEFT JOIN users u ON d.user_id=u.id "
            "LEFT JOIN departments de ON d.department_id = de.id "
            "WHERE d.audience='all' OR d.department_id IS NULL"
        )
        for row in cur.fetchall():
            it = dict(row)
            # Rellenar valores por defecto para evitar errores en la plantilla
            it.setdefault('user_name', None)
            it.setdefault('dept_abbr', None)
            it.setdefault('dept_logo', None)
            it.setdefault('description', '')
            items.append(it)
        # Menciones globales
        cur.execute(
            "SELECT 'Honor' AS type, h.title, h.description, h.image, h.created_at AS created_at, "
            "u.name AS user_name, de.abbreviation AS dept_abbr, de.logo AS dept_logo "
            "FROM honors h "
            "LEFT JOIN users u ON h.user_id=u.id "
            "LEFT JOIN departments de ON h.department_id = de.id "
            "WHERE h.audience='all' OR h.department_id IS NULL"
        )
        for row in cur.fetchall():
            it = dict(row)
            it.setdefault('user_name', None)
            it.setdefault('dept_abbr', None)
            it.setdefault('dept_logo', None)
            it.setdefault('description', '')
            items.append(it)
        # Condecoraciones globales: solo aquellas asignadas a un usuario
        cur.execute(
            "SELECT 'Award' AS type, a.title, a.description, a.image, a.created_at AS created_at, "
            "u.name AS user_name, de.abbreviation AS dept_abbr, de.logo AS dept_logo "
            "FROM awards a "
            "LEFT JOIN users u ON a.user_id=u.id "
            "LEFT JOIN departments de ON a.department_id = de.id "
            "WHERE a.user_id IS NOT NULL"
        )
        for row in cur.fetchall():
            it = dict(row)
            it.setdefault('user_name', None)
            it.setdefault('dept_abbr', None)
            it.setdefault('dept_logo', None)
            it.setdefault('description', '')
            items.append(it)
        conn.close()
        # Filtrar a los últimos 30 días y ordenar por fecha descendente
        now = datetime.utcnow()
        filtered = []
        for it in items:
            ts = it.get('created_at')
            # Convertir a datetime; aceptar diferentes formatos (con T o sin T)
            try:
                if ts and 'T' in ts:
                    dt = datetime.strptime(ts, "%Y-%m-%dT%H:%M:%S")
                elif ts:
                    dt = datetime.strptime(ts, "%Y-%m-%d %H:%M:%S")
                else:
                    dt = None
            except Exception:
                dt = None
            if dt is None or (now - dt) <= timedelta(days=30):
                filtered.append(it)
        filtered.sort(key=lambda x: x.get('created_at', ''), reverse=True)
        return render_template('hall_of_fame.html', items=filtered)

    @app.route('/admin/settings', methods=['GET', 'POST'])
    @login_required
    def manage_settings():
        """
        Permite a cúpula o staff cambiar la visibilidad de secciones académicas
        y personalizar la apariencia de la división (logo, favicon y colores).
        """
        dept_id = session.get('current_department_id')
        role_global = session.get('user_role')
        dept_role = session.get('current_dept_role')
        # Solo permiten acceso los usuarios de tipo staff o cupula de la división
        if not (role_global == 'admin' or dept_role == 'cupula'):
            flash('No tienes permisos para gestionar esta configuración.', 'danger')
            return redirect(url_for('dashboard'))
        conn = get_db_connection()
        cur = conn.cursor()
        # Asegurar que la fila de settings exista
        cur.execute("SELECT * FROM department_settings WHERE department_id=?", (dept_id,))
        settings = cur.fetchone()
        if not settings:
            cur.execute(
                "INSERT INTO department_settings (department_id, show_diplomas, show_honors, show_grades, show_hall_of_fame) VALUES (?,?,?,?,?)",
                (dept_id, 1, 1, 1, 1),
            )
            conn.commit()
            cur.execute("SELECT * FROM department_settings WHERE department_id=?", (dept_id,))
            settings = cur.fetchone()
        # Convert to dict for easier use
        settings_dict = dict(settings)
        if request.method == 'POST':
            section = request.form.get('section')
            if section == 'visibility':
                # Actualizar las banderas de visibilidad
                show_diplomas = 1 if request.form.get('show_diplomas') == 'on' else 0
                show_honors = 1 if request.form.get('show_honors') == 'on' else 0
                show_grades = 1 if request.form.get('show_grades') == 'on' else 0
                show_hof = 1 if request.form.get('show_hall_of_fame') == 'on' else 0
                cur.execute(
                    "UPDATE department_settings SET show_diplomas=?, show_honors=?, show_grades=?, show_hall_of_fame=? WHERE department_id=?",
                    (show_diplomas, show_honors, show_grades, show_hof, dept_id),
                )
                conn.commit()
                flash('Secciones actualizadas correctamente.', 'success')
            elif section == 'visual':
                import time
                # Personalización visual: logo, favicon y colores
                # Procesar logo
                logo_file = request.files.get('custom_logo')
                favicon_file = request.files.get('custom_favicon')
                primary_color = request.form.get('primary_color')
                bg_start = request.form.get('bg_start')
                bg_end = request.form.get('bg_end')
                updates = []
                params = []
                # Guardar logo si se subió
                if logo_file and logo_file.filename:
                    filename = f"dept_{dept_id}_logo_{int(time.time())}_{logo_file.filename.replace(' ', '_')}"
                    save_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                    logo_file.save(save_path)
                    updates.append("custom_logo=?")
                    params.append(filename)
                # Guardar favicon si se subió
                if favicon_file and favicon_file.filename:
                    filename = f"dept_{dept_id}_favicon_{int(time.time())}_{favicon_file.filename.replace(' ', '_')}"
                    save_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                    favicon_file.save(save_path)
                    updates.append("custom_favicon=?")
                    params.append(filename)
                # Colores
                if primary_color:
                    updates.append("primary_color=?")
                    params.append(primary_color)
                if bg_start:
                    updates.append("bg_start=?")
                    params.append(bg_start)
                if bg_end:
                    updates.append("bg_end=?")
                    params.append(bg_end)
                if updates:
                    query = f"UPDATE department_settings SET {', '.join(updates)} WHERE department_id=?"
                    params.append(dept_id)
                    cur.execute(query, params)
                    conn.commit()
                    flash('Personalización actualizada correctamente.', 'success')
            elif section == 'effects':
                # Guardar estados de efectos de temporada y vista previa OG
                enable_snow = 1 if request.form.get('enable_snow') == 'on' else 0
                enable_halloween = 1 if request.form.get('enable_halloween') == 'on' else 0
                enable_thanksgiving = 1 if request.form.get('enable_thanksgiving') == 'on' else 0
                enable_preview = 1 if request.form.get('enable_preview') == 'on' else 0
                cur.execute(
                    "UPDATE department_settings SET enable_snow=?, enable_halloween=?, enable_thanksgiving=?, enable_preview=? WHERE department_id=?",
                    (enable_snow, enable_halloween, enable_thanksgiving, enable_preview, dept_id),
                )
                conn.commit()
                flash('Efectos de temporada actualizados.', 'success')
            # Recargar ajustes tras cambios
        cur.execute("SELECT * FROM department_settings WHERE department_id=?", (dept_id,))
        settings = cur.fetchone()
        # Convertir a diccionario o usar diccionario vacío si no hay ajustes para evitar errores 500
        settings_dict = dict(settings) if settings else {}
        conn.close()
        return render_template('admin_settings.html', settings=settings_dict)

    @app.route('/uploads/<filename>')
    def uploaded_file(filename):
        """
        Permite servir archivos subidos (imágenes de perfil) desde el disco.
        """
        return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

    # ------------------------------------------------------------------
    # Notificaciones

    @app.route('/notifications')
    @login_required
    def notifications():
        """Muestra todas las notificaciones del usuario autenticado."""
        uid = session.get('user_id')
        if not uid:
            return redirect(url_for('login'))
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute(
            "SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC",
            (uid,)
        )
        notes = [dict(row) for row in cur.fetchall()]
        # Marcar todas como vistas
        cur.execute("UPDATE notifications SET seen=1 WHERE user_id=?", (uid,))
        conn.commit()
        conn.close()
        # Actualizar contador en sesión
        session['notifications_count'] = 0
        return render_template('notifications.html', notifications=notes)

    # ------------------------------------------------------------------
    # Documentos compartidos por división

    @app.route('/documents', methods=['GET', 'POST'])
    @login_required
    def documents():
        """
        Página de documentos importantes organizados por departamento. Los usuarios con permisos de
        cúpula o administradores pueden crear nuevos documentos con un título, descripción,
        enlace y una miniatura opcional. Los miembros normales sólo podrán ver y abrir los
        documentos existentes.
        """
        dept_id = session.get('current_department_id')
        role_global = session.get('user_role')
        dept_role = session.get('current_dept_role')
        conn = get_db_connection()
        cur = conn.cursor()
        if request.method == 'POST' and (role_global == 'admin' or dept_role == 'cupula'):
            title = (request.form.get('title') or '').strip()
            description = (request.form.get('description') or '').strip()
            link = (request.form.get('link') or '').strip()
            image_file = request.files.get('image')
            image_filename = None
            if image_file and image_file.filename:
                # Guardar imagen con nombre único
                import time
                from werkzeug.utils import secure_filename
                filename = secure_filename(image_file.filename)
                image_filename = f"doc_{int(time.time())}_{filename}"
                save_path = os.path.join(app.config['UPLOAD_FOLDER'], image_filename)
                image_file.save(save_path)
            cur.execute(
                "INSERT INTO documents (department_id, title, description, link, image, created_by) VALUES (?,?,?,?,?,?)",
                (dept_id, title, description, link, image_filename, session['user_id']),
            )
            conn.commit()
            flash('Documento publicado correctamente.', 'success')
            return redirect(url_for('documents'))
        # Obtener documentos globales o de la división actual, junto con nombre del autor
        cur.execute(
            "SELECT documents.*, users.name AS author FROM documents LEFT JOIN users ON documents.created_by = users.id WHERE (documents.department_id = ? OR documents.department_id IS NULL) ORDER BY documents.created_at DESC",
            (dept_id,),
        )
        docs = cur.fetchall()
        conn.close()
        return render_template('documents.html', documents=docs)

    # ------------------------------------------------------------------
    # Recuperación de contraseña y restablecimiento

    @app.route('/forgot_password', methods=['GET', 'POST'])
    def forgot_password():
        """Permite iniciar el proceso de recuperación de contraseña mediante correo electrónico."""
        if request.method == 'POST':
            email = request.form.get('email', '').strip().lower()
            if not email:
                flash('Debe indicar su correo electrónico.', 'warning')
                return render_template('forgot_password.html')
            conn = get_db_connection()
            cur = conn.cursor()
            cur.execute("SELECT id, name, email FROM users WHERE email=?", (email,))
            user = cur.fetchone()
            if user:
                token = os.urandom(24).hex()
                expires_at = (datetime.utcnow() + timedelta(hours=1)).strftime('%Y-%m-%d %H:%M:%S')
                cur.execute("INSERT INTO password_resets (user_id, token, expires_at) VALUES (?,?,?)", (user['id'], token, expires_at))
                conn.commit()
                try:
                    send_reset_email(user['email'], token)
                except Exception:
                    pass
                flash('Se han enviado instrucciones de recuperación si su correo está registrado.', 'success')
                conn.close()
                return redirect(url_for('login'))
            conn.close()
            flash('Se han enviado instrucciones de recuperación si su correo está registrado.', 'success')
            return redirect(url_for('login'))
        return render_template('forgot_password.html')

    def send_reset_email(to_email, token):
        """Envía un correo con el enlace de restablecimiento. El servidor SMTP debe estar configurado."""
        try:
            import smtplib
            from email.mime.text import MIMEText
            smtp_server = 'localhost'
            smtp_port = 25
            from_email = 'no-reply@example.com'
            subject = 'Restablecimiento de contraseña'
            reset_link = url_for('reset_password', token=token, _external=True)
            body = f"Hola,\n\nPara restablecer su contraseña haga clic en el siguiente enlace:\n{reset_link}\n\nSi no solicitó este correo, ignore este mensaje."
            msg = MIMEText(body)
            msg['Subject'] = subject
            msg['From'] = from_email
            msg['To'] = to_email
            with smtplib.SMTP(smtp_server, smtp_port) as server:
                server.sendmail(from_email, [to_email], msg.as_string())
        except Exception:
            # Como fallback, imprimir el enlace en consola para fines de prueba
            print(f"Enlace de restablecimiento para {to_email}: {url_for('reset_password', token=token, _external=True)}")

    @app.route('/reset/<token>', methods=['GET', 'POST'])
    def reset_password(token):
        """Página de restablecimiento de contraseña usando un token enviado por email."""
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("SELECT pr.*, u.id AS user_id FROM password_resets pr JOIN users u ON pr.user_id=u.id WHERE pr.token=?", (token,))
        row = cur.fetchone()
        if not row:
            conn.close()
            return render_template('reset_password.html', invalid_token=True)
        try:
            expires = datetime.strptime(row['expires_at'], '%Y-%m-%d %H:%M:%S')
        except Exception:
            expires = datetime.utcnow()
        if datetime.utcnow() > expires:
            cur.execute("DELETE FROM password_resets WHERE id=?", (row['id'],))
            conn.commit()
            conn.close()
            return render_template('reset_password.html', invalid_token=True)
        if request.method == 'POST':
            new_password = request.form.get('new_password')
            confirm = request.form.get('confirm_password')
            if not new_password or new_password != confirm:
                flash('Las contraseñas no coinciden.', 'warning')
                conn.close()
                return render_template('reset_password.html', invalid_token=False)
            hashed = generate_password_hash(new_password)
            cur.execute("UPDATE users SET password=? WHERE id=?", (hashed, row['user_id']))
            cur.execute("DELETE FROM password_resets WHERE id=?", (row['id'],))
            conn.commit()
            conn.close()
            flash('Contraseña restablecida correctamente. Ahora puede iniciar sesión.', 'success')
            return redirect(url_for('login'))
        conn.close()
        return render_template('reset_password.html', invalid_token=False)

    # ------------------------------------------------------------------
    # Comentarios a informes de incidencias

    @app.route('/admin/incident_comment/<int:report_id>', methods=['GET', 'POST'])
    @login_required
    def incident_comment(report_id):
        """Permite a la cúpula/administradores comentar un informe de incidencias."""
        # Verificar permisos: admin global o cupula de la división actual
        role_global = session.get('user_role')
        dept_role = session.get('current_dept_role')
        if role_global != 'admin' and dept_role != 'cupula':
            flash('No tiene permisos para acceder a esta sección.', 'danger')
            return redirect(url_for('dashboard'))
        conn = get_db_connection()
        cur = conn.cursor()
        # Obtener informe y convertirlo en dict para evitar AttributeError al usar .get()
        cur.execute(
            "SELECT sp_reports.*, users.name AS user_name FROM sp_reports JOIN users ON sp_reports.user_id=users.id WHERE sp_reports.id=?",
            (report_id,)
        )
        row = cur.fetchone()
        report = dict(row) if row else None
        if not report:
            conn.close()
            flash('Informe no encontrado.', 'warning')
            return redirect(url_for('admin_controls'))
        if request.method == 'POST':
            msg = request.form.get('message', '').strip()
            if msg:
                # Insertar comentario en la base de datos y confirmar antes de enviar notificaciones
                cur.execute(
                    "INSERT INTO sp_report_comments (report_id, user_id, message) VALUES (?,?,?)",
                    (report_id, session['user_id'], msg)
                )
                conn.commit()
                conn.close()
                # Después de confirmar, abrir una nueva conexión para evitar bloqueos durante las notificaciones
                conn_notify = get_db_connection()
                cur_notify = conn_notify.cursor()
                notified_ids = set()
                # Notificar al autor del informe si no es quien comentó
                if report['user_id'] != session['user_id']:
                    send_notification(
                        report['user_id'],
                        'Nuevo comentario en tu informe',
                        msg[:60] + ('...' if len(msg) > 60 else ''),
                        url_for('incident_conversation', report_id=report_id)
                    )
                    notified_ids.add(report['user_id'])
                # Notificar a los tripulantes adicionales
                trip_field = report.get('tripulantes') or ''
                for name in [n.strip() for n in trip_field.split(',') if n.strip()]:
                    cur_notify.execute("SELECT id FROM users WHERE name=?", (name,))
                    row_name = cur_notify.fetchone()
                    if row_name:
                        uid = row_name['id']
                        if uid != session['user_id'] and uid not in notified_ids:
                            send_notification(
                                uid,
                                'Nuevo comentario en un informe',
                                msg[:60] + ('...' if len(msg) > 60 else ''),
                                url_for('incident_conversation', report_id=report_id)
                            )
                            notified_ids.add(uid)
                conn_notify.close()
                flash('Comentario agregado.', 'success')
            return redirect(url_for('incident_comment', report_id=report_id))
        # Obtener comentarios para visualización
        cur.execute(
            "SELECT c.*, u.name AS user_name FROM sp_report_comments c JOIN users u ON c.user_id=u.id WHERE c.report_id=? ORDER BY c.created_at ASC",
            (report_id,)
        )
        comments = cur.fetchall()
        conn.close()
        return render_template('incident_comments.html', report=report, comments=comments, is_admin=True)

    @app.route('/incident/<int:report_id>/conversation', methods=['GET', 'POST'])
    @login_required
    def incident_conversation(report_id):
        """Permite al usuario del informe ver y responder a los comentarios."""
        user_id = session.get('user_id')
        conn = get_db_connection()
        cur = conn.cursor()
        # Verificar que el usuario sea el creador del informe o admin/cupula
        cur.execute("SELECT * FROM sp_reports WHERE id=?", (report_id,))
        rep = cur.fetchone()
        if not rep:
            conn.close()
            flash('Informe no encontrado.', 'warning')
            return redirect(url_for('dashboard'))
        # Comprobar permisos
        role_global = session.get('user_role')
        dept_role = session.get('current_dept_role')
        if rep['user_id'] != user_id and role_global != 'admin' and dept_role != 'cupula':
            conn.close()
            flash('No tiene permisos para ver esta conversación.', 'danger')
            return redirect(url_for('dashboard'))
        if request.method == 'POST':
            msg = request.form.get('message', '').strip()
            if msg:
                cur.execute(
                    "INSERT INTO sp_report_comments (report_id, user_id, message, read_by_trooper) VALUES (?,?,?,0)",
                    (report_id, user_id, msg)
                )
                conn.commit()
            conn.close()
            return redirect(url_for('incident_conversation', report_id=report_id))
        # Obtener comentarios
        cur.execute(
            "SELECT c.*, u.name AS user_name FROM sp_report_comments c JOIN users u ON c.user_id=u.id WHERE c.report_id=? ORDER BY c.created_at ASC",
            (report_id,)
        )
        comments = cur.fetchall()
        conn.close()
        return render_template('incident_comments.html', report=rep, comments=comments, is_admin=False)

    @app.route('/admin/incident_stats')
    @login_required
    def admin_incident_stats():
        """Genera un resumen de incidentes aprobados por tipo y usuario para supervisión."""
        # Sólo visible para personal administrativo o cúpula
        role_global = session.get('user_role')
        dept_role = session.get('current_dept_role')
        if role_global != 'admin' and dept_role != 'cupula':
            flash('No tiene permisos para acceder a esta sección.', 'danger')
            return redirect(url_for('dashboard'))
        conn = get_db_connection()
        cur = conn.cursor()
        # Obtener lista de tipos de informe distintos
        cur.execute("SELECT DISTINCT report_type FROM sp_reports")
        types = [row['report_type'] for row in cur.fetchall() if row['report_type']]
        types.sort()
        # Obtener usuarios
        cur.execute("SELECT id, name FROM users")
        users = cur.fetchall()
        # Construir estructura de conteo
        data = []
        for u in users:
            uid = u['id']
            name = u['name']
            row = {'name': name}
            for t in types:
                cur.execute(
                    "SELECT COUNT(*) AS c FROM sp_reports WHERE user_id=? AND report_type=? AND approved=1",
                    (uid, t)
                )
                count = cur.fetchone()['c']
                row[t] = count
            data.append(row)
        conn.close()
        return render_template('admin_incident_stats.html', types=types, data=data)


    return app

if __name__ == '__main__':
    app = create_app()
    app.run(host='0.0.0.0', port=5000, debug=True)