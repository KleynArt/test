#!/usr/bin/env python3
from gunicorn.app.wsgiapp import run

if __name__ == "__main__":
    run()
