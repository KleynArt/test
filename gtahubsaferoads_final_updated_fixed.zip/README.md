# Sistema de Reportes de Patrullaje

Este proyecto es una demostración de un sistema web para registrar patrullajes policiales con un diseño inspirado en iOS. Permite a los usuarios registrarse, iniciar sesión, crear reportes de patrullaje y gestionar su propio perfil. Los administradores pueden aprobar cuentas, promover usuarios a administradores, revisar y filtrar reportes, y suspender cuentas.

## Características

- **Registro e inicio de sesión:** los usuarios pueden crear una cuenta (que debe ser aprobada por un administrador) e iniciar sesión para acceder al sistema.
- **Panel principal:** muestra un resumen de los últimos reportes y brinda acceso rápido a las acciones más comunes.
- **Creación de reportes:** formulario para registrar detalles como matrícula de la unidad, fecha, hora de inicio y fin, acompañantes, ubicación, descripción y observaciones.
- **Lista y filtrado de reportes:** los usuarios ven sus propios reportes y los administradores pueden ver todos; incluye filtros por unidad, usuario y rango de fechas.
- **Gestión de usuarios (admin):** aprobación de cuentas, suspensión, promoción y degradación de roles.
- **Edición de perfil:** los usuarios pueden actualizar su nombre, correo, contraseña y subir una imagen de perfil.
- **Interfaz estética:** usa Bootstrap y estilos personalizados para lograr un aspecto oscuro con efectos de vidrio (glassmorphism) recordando el estilo de iOS.

## Instalación

1. Clona o descarga este repositorio en tu máquina local.
2. Asegúrate de tener Python 3.8 o superior instalado.
3. Instala las dependencias usando pip:
   ```bash
   pip install -r requirements.txt
   ```
4. Ejecuta la aplicación:
   ```bash
   python app.py
   ```
5. Visita `http://localhost:5000` en tu navegador para acceder al sistema.

Por defecto se crea un usuario administrador con credenciales:

- **Usuario:** `admin`
- **Contraseña:** `admin123`

Se recomienda cambiar la contraseña del administrador en producción y proteger mejor la clave secreta.

## Notas

- Los archivos subidos se guardan en la carpeta `static/uploads`. Asegúrate de que esta ruta tenga permisos de escritura.
- Para cambiar el estilo o añadir logotipos personalizados, reemplaza la imagen de fondo en `static/images/background.png` y ajusta los estilos en `static/css/styles.css`.
- El mensaje "Creado por KleynArt" se muestra como marca de agua en la parte inferior de la pantalla.